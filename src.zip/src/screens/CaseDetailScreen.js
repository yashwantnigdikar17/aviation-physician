import React, { useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  TextInput,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Image } from "react-native";
// import MaterialIcons from "react-native-vector-icons/MaterialIcons";

import SendIcon from "../assets/Images/sendicon.svg";
import VideoIcon from "../assets/Images/videoicon.svg";
import MaterialIcons from "react-native-vector-icons/MaterialIcons";
import MaterialCommunityIcons from "react-native-vector-icons/MaterialCommunityIcons";
import { useNavigation } from "@react-navigation/native";
import ExclaimIcon from "../assets/Images/exclaimation.svg";
import SpO2Card from "../components/spo2component";
import Clock from "../assets/Images/clock.svg";
import AvatarIcon from "../assets/Images/avatar.svg"; // adjust name if different
import Sidebar from "../components/Sidebar";
import RightVitalsPanel from "../components/RightVitalsPanel";


//Vital trend popup (CLEAN VERSION)
const VitalsTrendPanel = ({ onClose }) => {
  return (
    <View style={{ flex: 1, backgroundColor: "#FFFFFF" }}>

      {/* 🔥 HEADER */}
      <View style={styles.vitalsHeader}>
        <Text style={styles.vitalsTitle}>Vital Trends</Text>

        <TouchableOpacity onPress={onClose}>
          <MaterialIcons name="close" size={20} color="#111" />
        </TouchableOpacity>
      </View>

      {/* 🔥 CONTENT */}
      <ScrollView
        style={{ flex: 1 }}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ padding: 12 }}
      >
        <SpO2Card />
      </ScrollView>

    </View>
  );
};

const TiaSuggestPanel = () => (
  <View>

    <View style={styles.tiaHeader}>
      <MaterialIcons name="auto-awesome" size={14} color="#0A5FFF" />
      <Text style={styles.tiaHeaderText}>TIA Suggests</Text>
    </View>

    {/* MEDICINES */}
    <View style={styles.tiaCard}>
      <View style={styles.tiaCardHeader}>
        <Text style={styles.tiaCardTitle}>Suggested Medicines</Text>
        <MaterialIcons name="close" size={14} />
      </View>

      <Text style={styles.tiaSub}>Medicine in Stock</Text>

      <View style={styles.tiaItem}>
         <Text style={styles.tiaItemText}>💊 Atropine Sulfate 600mcg /ml</Text>
      </View>

      <View style={styles.tiaItem}>
         <Text style={styles.tiaItemText}>💊  Aspirin 300 mg tablets</Text>
      </View>
    </View>

    {/* ESSENTIALS */}
    <View style={styles.tiaCard}>
      <View style={styles.tiaCardHeader}>
        <Text style={styles.tiaCardTitle}>Suggested essentials</Text>
        <MaterialIcons name="close" size={14} />
      </View>

      <Text style={styles.tiaSub}>Equipment in Stock</Text>

      <View style={styles.tiaItem}>
        <Text style={styles.tiaItemText}>📈   Pen Torch</Text>
      </View>

      <View style={styles.tiaItem}>
        <Text style={styles.tiaItemText}>📊   Pulse Ox</Text>
      </View>
    </View>

    {/* INFO */}
    <View style={styles.tiaInfoCard}>
      <Text style={styles.tiaInfoText}>

        Recent entries show normal activity levels and predictable routines.
      </Text>
    </View>

  </View>
);

// ─────────────────────────────────────────────
// INSTRUCTION CARDS
// ─────────────────────────────────────────────
const INSTRUCTIONS = [
  {
    icon: "airline-seat-flat",
    title: "Lay the passenger flat",
    desc: "Rest the passenger on the floor —\nnot seated",
    color: "#1565C0",
    bg: "#EBF2FF",
  },
  {
    icon: "arrow-downward",
    title: "Gently lower to floor",
    desc: "Support head & neck.\nDo NOT leave seated.",
    color: "#F59E0B",
    bg: "#EBF2FF",
  },
  {
    icon: "accessibility",
    title: "Raise legs 30–45 cm",
    desc: "Use a bag, pillow, or rolled\nblanket.",
    color: "#F59E0B",
    bg: "#EBF2FF",
  },
  {
    icon: "checkroom",
    title: "Loosen tight clothing",
    desc: "Collar, belt, tie — let blood\nflow freely.",
    color: "#1565C0",
    bg: "#EBF2FF",
  },
];

const InstructionCard = ({ icon, title, desc, color, bg }) => (
  <View style={[styles.instrCard, { backgroundColor: bg }]}>
    <View style={[styles.instrIconWrap, { backgroundColor: color + "20" }]}>
      <MaterialIcons name={icon} size={16} color={color} />
    </View>
    <Text style={styles.instrTitle}>{title}</Text>
    <Text style={styles.instrDesc}>{desc}</Text>
  </View>
);

// 🔥 ONLY CHANGES APPLIED — REST SAME

export default function CaseDetailScreen({ navigation }) {
  const [message, setMessage] = useState("");
  const [showTrends, setShowTrends] = useState(false);
  const [activeTab, setActiveTab] = useState("summary");
  const insets = useSafeAreaInsets();

  return (
    <View style={styles.safe}>
      <View style={styles.root}>
        <Sidebar activeKey="medicines" navigation={navigation} />

        <View style={styles.mainContent}>
          {/* HEADER */}
          <View style={[styles.patientHeader, { paddingTop: insets.top }]}>
            <View>
              <Text style={styles.patientName}>John Smith, 58 M</Text>
              <Text style={styles.patientFlight}>
                Flight AA1234, SYD → LAX
              </Text>
            </View>

            <View style={{ flex: 1 }} />

            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <TouchableOpacity
                style={styles.joinNowBtn}
                onPress={() =>
                  navigation.navigate("Meeting", {
                    roomId: "test123",
                    userName: "Sakshi",
                  })
                }
              >
                <VideoIcon width={22} height={22} />
                <Text style={styles.joinNowText}>Join Now</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.bellBtn}>
                <MaterialIcons
                  name="notifications-none"
                  size={18}
                  color="#fff"
                />
              </TouchableOpacity>
            </View>
          </View>

          {/* BODY */}
          <View style={styles.body}>
            <View style={styles.leftPanel}>

              {/* 🔥 NEW PERFECT TABS */}
              <View style={styles.tabWrapper}>
                <TouchableOpacity
                  style={[
                    styles.tabBtn,
                    activeTab === "summary" && styles.tabActive,
                  ]}
                  onPress={() => setActiveTab("summary")}
                >
                  <MaterialIcons
                    name="event-note"
                    size={14}
                    color={activeTab === "summary" ? "#fff" : "#6B7280"}
                  />
                  <Text
                    style={[
                      styles.tabText,
                      activeTab === "summary" && styles.tabTextActive,
                    ]}
                     numberOfLines={1}
                     ellipsizeMode="tail"   // 🔥 prevents breaking
                  >
                    Event summary
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[
                    styles.tabBtn,
                    activeTab === "chat" && styles.tabActive,
                  ]}
                  onPress={() => setActiveTab("chat")}
                >
                  <MaterialIcons
                    name="chat-bubble-outline"
                    size={14}
                    color={activeTab === "chat" ? "#fff" : "#6B7280"}
                  />
                  <Text
                    style={[
                      styles.tabText,
                      activeTab === "chat" && styles.tabTextActive,
                    ]}
                  >
                    Chat
                  </Text>
                </TouchableOpacity>
              </View>

              {/* ✅ EVENT SUMMARY */}
              {activeTab === "summary" && (
                <ScrollView
                  style={{ paddingHorizontal: 16 }}
                  showsVerticalScrollIndicator={false}
                >
                  <Text style={styles.summaryTitle}>Event Summary</Text>

                  
                  <Text style={styles.cardBodyText}>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur laborum.
                  </Text>
                 
                  <Text style={styles.cardBodyText}>
                    { '\n'} Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
                  </Text>
                   <Text style={styles.cardBodyText}>
                    { '\n'} Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
                  </Text>
                   <Text style={styles.cardBodyText}>
                    { '\n'} Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
                  </Text>
                   <Text style={styles.cardBodyText}>
                    { '\n'} Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
                  </Text>
                   <Text style={styles.cardBodyText}>
                    { '\n'} Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
                  </Text>
                   <Text style={styles.cardBodyText}>
                    { '\n'} Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                  </Text>
                </ScrollView>
              )}

              {/* ✅ CHAT */}
              {activeTab === "chat" && (
                <View style={styles.instructionsContainer}>
                  <ScrollView
                    style={{ flex: 1 }}
                    showsVerticalScrollIndicator={false}
                    contentContainerStyle={{ padding: 12 }}
                  >
                    <Text style={styles.cardSectionLabel}>Julia (Crew)</Text>

                    {/* <View style={styles.cardSectionWhite}>
                      <View style={styles.pathwayHeader}>
                        <Text style={styles.pathwayTitle}>
                          Pathway A - Vasovagal
                        </Text>
                      </View>

                      <Text style={styles.pathwaySubtitle}>
                        Below instructions will go to Crew for guidance
                      </Text>

                      <View style={styles.instrGrid}>
                        {INSTRUCTIONS.map((i, index) => (
                          <InstructionCard key={index} {...i} />
                        ))}
                      </View>

                      <Text style={styles.pathwayText}>
                        Dr. Sarah Johnson • 14/03/2026 • 14:28
                      </Text>
                    </View> */}

                    <View style={styles.chatWrapper}>
                      <View style={styles.chatBubble}>
                        <Text style={styles.chatText}>
                          Record observations every 2 hours.
                          {"\n"}Track sleep duration and overall rest quality.
                        </Text>

                        <Text style={styles.chatFooter}>
                          Dr. Sarah Johnson • 14/03/2026 • 14:28
                        </Text>
                      </View>
                      <View style={styles.avatarWrapper}>
                        <AvatarIcon width={45} height={45} />
                      </View>
                    </View>

                    

                     <View style={styles.chatWrapper2}>
                      <View style={styles.chatBubble2}>
                        <View style={styles.imageContainer}>
  
  <Image
    source={require("../assets/Images/chatimg.png")}
    style={styles.image}
    resizeMode="cover"
  />

  {/* 🔥 PLAY BUTTON OVERLAY */}
  <View style={styles.playOverlay}>
    <MaterialIcons name="play-arrow" size={40} color="#fff" />
  </View>

</View>

                        <Text style={styles.chatFooter}>
                         Chief Purser • 14/03/2026 • 14:30
                        </Text>
                      </View>
                      <View style={styles.avatarWrapper2}>
                        <AvatarIcon width={45} height={45} />
                      </View>
                    </View>

                    <View style={styles.chatWrapper}>
                      <View style={styles.chatBubble}>
                        <Text style={styles.chatText}>
                          Record observations every 2 hours.
                          {"\n"}Track sleep duration and overall rest quality.
                        </Text>

                        <Text style={styles.chatFooter}>
                          Dr. Sarah Johnson • 14/03/2026 • 14:28
                        </Text>
                      </View>
                      <View style={styles.avatarWrapper}>
                        <AvatarIcon width={45} height={45} />
                      </View>
                    </View>
                  </ScrollView>

                  {/* INPUT */}
                  <View style={styles.chatInputBar}>
                    <TextInput
                      style={styles.chatInput}
                      placeholder="Click on the mic or type.."
                      placeholderTextColor="#7F7F7F"
                      value={message}
                      onChangeText={setMessage}
                    />

                    <TouchableOpacity style={styles.iconCircleBtn}>
                      <MaterialIcons
                        name="mic"
                        size={16}
                        color="#015DFF"
                      />
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.sendBtn}>
                      <SendIcon width={14} height={14} />
                      <Text style={styles.sendBtnText}>Send</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              )}
            </View>
          </View>
        </View>

        {/* TIA PANEL */}
      <View style={styles.tiaPanel(insets)}>
  {showTrends ? (
    <SpO2Card onClose={() => setShowTrends(false)} />
  ) : (
    <TiaSuggestPanel />
  )}
</View>

        {/* RIGHT PANEL */}
        <View style={[styles.rightPanelWrapper, { paddingTop: insets.top }]}>
          <RightVitalsPanel
            onShowTrends={() => setShowTrends(true)}
            onECGPress={() => navigation.navigate("ECGScreen")}
          />
        </View>
      </View>
    </View>
  );
}
// ─────────────────────────────────────────────
// STYLES
// ─────────────────────────────────────────────
const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: "#EEF2F7",
  },

  root: {
    flex: 1,
    flexDirection: "row",
  },

  mainContent: {
    flex: 1,
    flexDirection: "column",
    backgroundColor: "#FFFFFF",
  },
  //Chat
  chatWrapper: {
    marginTop: 10,
    alignItems: "flex-end",
    marginRight: 50,
  },
   chatWrapper2: {
    marginTop: 10,
    alignItems: "flex-start",
    marginRight: 10,
  },
  chatBubble: {
    backgroundColor: "#FFFFFF", // ✅ white
    padding: 10,
    borderRadius: 12,
    maxWidth: "75%",
  },
   chatBubble2: {
    backgroundColor: "#FFFFFF", // ✅ white
    padding: 10,
    borderRadius: 12,
     maxWidth: "75%",
     marginLeft: 50,
    marginTop:10
  },

  chatText: {
    fontSize: 12,
    color: "#1F2024",
    lineHeight: 16,
  },
  chatFooter: {
    marginTop: 6,
    fontSize: 10,
    color: "#6B7280",
  },
  avatarWrapper: {
    position: "absolute",
    right: -55,
    bottom: -3,
    width: 45,
    height: 45,
    borderRadius: 40,
    alignItems: "center",
    justifyContent: "center",
  },

  
  avatarWrapper2: {
position: "absolute",
    left: 0,
    bottom: -3,
    width: 45,
    height: 45,
    borderRadius: 40,
    alignItems: "center",
    justifyContent: "center",
  },
  // ── HEADER ─────────────────────────
  patientHeader: {
    flexDirection: "row",
    alignItems: "center",
    width: 710,
    paddingHorizontal: 14, //was 18
    paddingVertical: 8, // was 12
    backgroundColor: "#FFFFFF",
    borderBottomWidth: 1,
    borderBottomColor: "#E6EAF0",
    marginTop: 15,
  },
  tiaPanel: (insets) => ({
    width: 273,
    backgroundColor: "#F6F9FF",
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: "#E6EAF0",

    // Full height
    height: "100%",

    // Remove any top gap
    marginTop: 0,

    // Safe area handling
    paddingTop: insets.top + 14,
    paddingHorizontal: 14,
    paddingBottom: 14,
    overflow: "hidden",
  }),
  tabWrapper: {
  flexDirection: "row",
  backgroundColor: "#E5E7EB",
  borderRadius: 30,
  padding: 4,
  margin: 12,
    alignSelf: "flex-start",
  
},

tabBtn: {
 flexDirection: "row",        // 🔥 important
  alignItems: "center",        // 🔥 vertical center
  justifyContent: "center",    // optional but cleaner
  gap: 6,
  paddingHorizontal: 14,
  paddingVertical: 8,
  borderRadius: 20,
  flexWrap: "nowrap",   // 🔥 PREVENT WRAP
},
vitalsHeader: {
  flexDirection: "row",
  alignItems: "center",
  justifyContent: "space-between",

  paddingHorizontal: 12,
  paddingVertical: 10,

  borderBottomWidth: 1,
  borderBottomColor: "#E5E7EB",
},

vitalsTitle: {
  fontSize: 14,
  fontWeight: "700",
  color: "#111827",
},
tabActive: {
  backgroundColor: "#1565C0",
},

tabText: {
  fontSize: 12,
  color: "#6B7280",
  fontWeight: "500",
   marginLeft: 6,
  flexShrink: 1,
},

tabTextActive: {
  color: "#fff",
},

summaryTitle: {
  fontSize: 14,
  fontWeight: "700",
  marginBottom: 8,
  color: "#111827",
},

summaryText: {
  fontSize: 12,
  color: "#4B5563",
  lineHeight: 18,
},
  tiaHeader: {
    marginTop: 30,
    flexDirection: "row",
    paddingHorizontal: 10,
    alignItems: "center",
    marginBottom: 12,
    gap: 6,
  },

  instructionsContainer: {
    flex: 1,
    backgroundColor: "#F6F9FF",
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
    overflow: "hidden",
  },
  tiaHeaderText: {
    fontSize: 13,
    fontWeight: "600",
    color: "#1F2024",
  },
  tiaTitle: {
    color: "#FFFFFF",
    fontSize: 13,
    fontWeight: "600",
  },

  tiaContent: {
    marginBottom: 16,
  },
  tiaMedCardLight: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#F3F5F9",
    borderRadius: 12,
    padding: 10,
    marginBottom: 10,
    gap: 8,
  },
tiaItemText: {
  color: "#000000",
  fontSize: 11,
},
  tiaMedTitleDark: {
    color: "#1F2024",
    fontSize: 11,
    fontWeight: "600",
  },
  tiaSection: {
    fontSize: 10,
    color: "#9CA3AF",
    marginBottom: 8,
    paddingHorizontal: 15,
  },

  tiaChipRow: {
    flexDirection: "row",
    gap: 8,
    marginBottom: 12,
  },

  tiaChip: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#1F2937",
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 6,
    gap: 6,
  },

  tiaChipText: {
    color: "#E5E7EB",
    fontSize: 11,
  },

  tiaChipLight: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#F3F5F9",
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 6,
    gap: 6,
  },

  tiaChipTextDark: {
    color: "#1F2024",
    fontSize: 11,
  },

  tiaMedCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#1F2937",
    borderRadius: 16,
    padding: 10,
    marginBottom: 10,
    gap: 8,
  },

  tiaMedIcon: {
    fontSize: 14,
  },

  tiaMedTitle: {
    color: "#E5E7EB",
    fontSize: 11,
    fontWeight: "600",
  },

  tiaMedSub: {
    color: "#9CA3AF",
    fontSize: 10,
  },

  patientAvatar: {
    width: 36,
    height: 36,
    borderRadius: 22,
    backgroundColor: "#E6EBF2",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 10,
  },

  patientName: {
    fontSize: 21,
    fontWeight: "700",
    fontStyle: "Bold",
    color: "#1F2024",
  },
tabRow: {
  flexDirection: "row",
  gap: 8,
  margin: 10,
},



tabActive: {
  backgroundColor: "#1565C0",
},

tabInactive: {
  backgroundColor: "#E5E7EB",
},

tabText: {
  fontSize: 12,
  color: "#111",
},

tabTextActive: {
  color: "#fff",
},

tiaCard: {
  backgroundColor: "#EAF2FF",
  borderRadius: 12,
  padding: 10,
  marginBottom: 10,
},

tiaCardHeader: {
  flexDirection: "row",
  justifyContent: "space-between",
},

tiaCardTitle: {
  fontSize: 12,
  fontWeight: "600",
  color:'#000000'
},

tiaSub: {
  fontSize: 10,
  color: "#6B7280",
  marginVertical: 6,
},

tiaItem: {
  backgroundColor: "#fff",
  padding: 8,
  borderRadius: 8,
  marginBottom: 6,
  color:'#000000'
},

tiaInfoCard: {
  backgroundColor: "#EAF2FF",
  padding: 10,
  borderRadius: 12,
},

tiaInfoText: {
  fontSize: 11,
  color: "#374151",
},
  patientFlight: {
    fontSize: 11,
    color: "#1F2024",
    marginTop: 2,
    fontWeight: 400,
  },

  joinNowBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: "#015DFF",
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },

  joinNowText: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "600",
  },

  bellBtn: {
    width: 38,
    height: 38,
    borderRadius: 12,
    backgroundColor: "#015DFF",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "#E2E6EC",
    marginLeft: 8,
  },

  // ── BODY ─────────────────────────
  body: {
    flex: 1,
    flexDirection: "row",
  },

  // ── LEFT PANEL ─────────────────────────
  leftPanel: {
    flex: 1,
    backgroundColor: "#FFFFFF", // lighter clean bg
  },

  chatScroll: {
    flex: 1,
    paddingHorizontal: 12, // was 16
    paddingTop: 8, // was 14
  },

  card: {
    backgroundColor: "#F6F9FF",
    borderRadius: 12, // was 14
    padding: 12, // was 16
    marginBottom: 10, // was 14
    borderBottomLeftRadius: 0,
    borderBottomRightRadius: 0,
  },

  cardSectionLabel: {
    fontSize: 12, // was 13
    fontWeight: "700",
    color: "#1F2024",
    marginBottom: 2,
  },
  cardSectionWhite: {
    backgroundColor: "#FFF",
    padding: 10, // was 12
    borderRadius: 8,
    gap: 4, // was 6
    marginBottom: 0, // was 50
  },
  cardBodyText: {
    fontSize: 12, // was 13
    color: "#4B5563",
    lineHeight: 16, // was 18
  },

  viewMoreRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 6,
  },

  viewMoreText: {
    fontSize: 9.6,
    color: "#0A5FFF",
    fontWeight: "600",
    marginRight: 4,
  },

  // avatar bubble
  patientAvatarBubble: {
    paddingLeft: 6,
    marginBottom: 12,
  },

  patientAvatarCircle: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: "#E6EBF2",
    alignItems: "center",
    justifyContent: "center",
  },

  // ── PATHWAY ─────────────────────────
  pathwayHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 4,
  },

  pathwayTitle: {
    fontSize: 13,
    fontWeight: "700",
    color: "#1F2024",
  },

  pathwayBadge: {
    backgroundColor: "#E3ECFF",
    borderRadius: 12,
    paddingHorizontal: 10,
    paddingVertical: 3,
    marginLeft: 6,
  },

  pathwayBadgeText: {
    fontSize: 11,
    color: "#0A5FFF",
    fontWeight: "600",
  },

  pathwaySubtitle: {
    fontSize: 11,
    color: "#6B7280",
    marginBottom: 12,
  },

  pathwayText: {
    fontSize: 10,
    color: "#6B7280",
    marginBottom: 5,
  },

  // ── INSTRUCTIONS GRID ─────────────────────────
  instrGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },

  instrCard: {
    width: "48%",
    backgroundColor: "#DCE3ED", // inner lighter
    borderRadius: 10, //was 12
    padding: 8, //was 12
    marginBottom: 8, // was 8
  },

  instrIconWrap: {
    width: 26, //was 32
    height: 26, //was 32
    borderRadius: 8, //was 10
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 4, //was 6
  },

  instrTitle: {
    fontSize: 10, //was 11
    fontWeight: "700",
    color: "#1F2024",
    marginBottom: 3,
  },

  instrDesc: {
    fontSize: 9, //was 10
    color: "#6B7280",
    lineHeight: 12, //was 14
  },

  instrFooter: {
    fontSize: 10,
    color: "#9CA3AF",
    marginTop: 10,
  },

  // ── CHAT INPUT ─────────────────────────
  chatInputBar: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#EAF1FF",
    borderTopWidth: 1,
    borderTopColor: "#E6EAF0",
    paddingHorizontal: 10, //was 14
    paddingVertical: 6, // was 8
    marginTop: 0, //was -24
    marginBottom: 10,
    marginLeft: 12,
    borderBottomLeftRadius: 12,
    borderBottomRightRadius: 12,
    borderTopLeftRadius: 0,
    borderTopRightRadius: 0,
    width: "96.5%",
  },

  chatInput: {
    flex: 1,
    fontSize: 14,
    fontWeight: 500,
    color: "#1F2024",
  },

  iconCircleBtn: {
    width: 40,
    height: 40,
    borderRadius: 50,
    borderWidth: 1,
    borderColor: "#015DFF",
    backgroundColor: "#EAF1FF",
    alignItems: "center",
    justifyContent: "center",
    marginLeft: 8,
  },

  sendBtn: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#0A5FFF",
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginLeft: 8,
  },

  sendBtnText: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "600",
    marginLeft: 4,
  },

  // ── KIT PANEL ─────────────────────────
  kitPanel: {
    width: 240,
    backgroundColor: "#FFFFFF",
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: "#E6EAF0",
    padding: 16,
  },

  kitTitle: {
    fontSize: 13,
    fontWeight: "700",
    color: "#1F2024",
  },

  kitSubtitle: {
    fontSize: 11,
    color: "#6B7280",
    marginBottom: 12,
  },

  medicationCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FFF6E6",
    borderRadius: 12,
    padding: 10,
    marginBottom: 10,
  },

  findMedBtn: {
    backgroundColor: "#0A5FFF",
    borderRadius: 24,
    paddingVertical: 12,
    alignItems: "center",
  },

  findMedBtnText: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "600",
  },

  // ── RIGHT PANEL ─────────────────────────
  rightPanelWrapper: {
    width: 218,
    backgroundColor: "#0F172A",
    paddingHorizontal: 12, // tighter
    paddingBottom: 16,
  },

  //Trend
  trendBtn: {
    backgroundColor: "#1E293B",
    borderRadius: 10,
    paddingVertical: 8,
    alignItems: "center",
    marginBottom: 12,
  },

  trendText: {
    color: "#E2E8F0",
    fontSize: 11,
  },

  trendCard: {
    backgroundColor: "#EEF2F7",
    borderRadius: 10,
    padding: 10,
    marginBottom: 10,
  },

  trendTitle: {
    fontSize: 12,
    fontWeight: "600",
    marginBottom: 6,
    color: "black",
  },

  fakeGraph: {
    height: 60,
    backgroundColor: "#DCE3ED",
    borderRadius: 6,
  },

  alertBox: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#EED3D3",
    borderRadius: 16,
    padding: 14,
    gap: 10,
    marginTop: 7,
  },

  alertIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: "#EF4444",

    alignItems: "center",
    justifyContent: "center",
  },
  alertTitle: {
    fontSize: 13,
    fontWeight: "700",
    color: "#111",
    marginBottom: 4,
  },

  alertText: {
    fontSize: 11,
    color: "#4B5563",
    lineHeight: 18,
  },

  reminderBtn: {
    flexDirection: "row", // 👈 row layout
    alignItems: "center", // 👈 vertical center
    justifyContent: "center",
    marginTop: 7,
    backgroundColor: "#16A34A",
    paddingVertical: 12,
    borderRadius: 10,

    gap: 8, // 👈 spacing between icon & text
  },
  reminderText: {
    color: "#fff",
    fontSize: 13,
    fontWeight: "600",
  },
});
