// screens/ECGScreen.js
import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  StatusBar,
  SafeAreaView,
} from "react-native";
import Svg, { Line, Polyline, Text as SvgText, Rect } from "react-native-svg";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import Sidebar from "../components/Sidebar";
import { DetailedTopBar } from "../components/TopBar";

// ─── ECG waveform generator ───────────────────────────────────────────────────
const generateECGPoints = (width, height, cycles = 8, pattern = "normal") => {
  const points = [];
  const baseline = height * 0.6;
  const cycleWidth = width / cycles;

  for (let c = 0; c < cycles; c++) {
    const ox = c * cycleWidth;

    points.push([ox, baseline]);
    points.push([ox + cycleWidth * 0.08, baseline]);
    points.push([ox + cycleWidth * 0.12, baseline - height * 0.08]);
    points.push([ox + cycleWidth * 0.16, baseline]);
    points.push([ox + cycleWidth * 0.22, baseline]);
    points.push([ox + cycleWidth * 0.24, baseline + height * 0.06]);

    const rHeight = pattern === "tachy" ? height * 0.65 : height * 0.55;
    points.push([ox + cycleWidth * 0.27, baseline - rHeight]);
    points.push([ox + cycleWidth * 0.3, baseline + height * 0.1]);

    const stElevation = pattern === "stemi" ? -height * 0.12 : 0;
    points.push([ox + cycleWidth * 0.35, baseline + stElevation]);
    points.push([ox + cycleWidth * 0.42, baseline + stElevation]);

    const tHeight = pattern === "stemi" ? height * 0.2 : height * 0.14;
    points.push([ox + cycleWidth * 0.5, baseline - tHeight + stElevation]);
    points.push([ox + cycleWidth * 0.58, baseline]);
    points.push([ox + cycleWidth * 0.95, baseline]);
  }

  points.push([width, baseline]);
  return points;
};

// ─── ECGChart ────────────────────────────────────────────────────────────────
const ECGChart = ({
  width,
  height = 160,
  pattern = "normal",
  cycles = 8,
  timeLabels = [],
}) => {
  if (!width) return null;

  const pts = generateECGPoints(width, height, cycles, pattern);
  const polylinePoints = pts.map((p) => `${p[0]},${p[1]}`).join(" ");

  const smallGrid = 10;
  const bigGrid = 50;

    return (
      
    <Svg width={width} height={height + 16}>
      <Rect width={width} height={height} fill="#fff" />

      {/* Light grid */}
      {[...Array(Math.ceil(width / smallGrid))].map((_, i) => (
        <Line
          key={i}
          x1={i * smallGrid}
          y1={0}
          x2={i * smallGrid}
          y2={height}
          stroke="#E6E6E6"
          strokeWidth="0.5"
        />
      ))}
      {[...Array(Math.ceil(height / smallGrid))].map((_, i) => (
        <Line
          key={i}
          x1={0}
          y1={i * smallGrid}
          x2={width}
          y2={i * smallGrid}
          stroke="#E6E6E6"
          strokeWidth="0.5"
        />
      ))}

      {/* Bold grid */}
      {[...Array(Math.ceil(width / bigGrid))].map((_, i) => (
        <Line
          key={`b${i}`}
          x1={i * bigGrid}
          y1={0}
          x2={i * bigGrid}
          y2={height}
          stroke="#CFCFCF"
          strokeWidth="1"
        />
      ))}
      {[...Array(Math.ceil(height / bigGrid))].map((_, i) => (
        <Line
          key={`bh${i}`}
          x1={0}
          y1={i * bigGrid}
          x2={width}
          y2={i * bigGrid}
          stroke="#CFCFCF"
          strokeWidth="1"
        />
      ))}

      {/* ECG waveform */}
      <Polyline
        points={polylinePoints}
        fill="none"
        stroke="#E53935"
        strokeWidth="1.5"
      />

      {/* Time labels */}
      {timeLabels.map((lbl, i) => (
        <SvgText
          key={i}
          x={i * bigGrid}
          y={height + 12}
          fontSize="8"
          fill="#999"
        >
          {lbl}
        </SvgText>
      ))}
    </Svg>
  );
};

// ─── MeasuredChart ────────────────────────────────────────────────────────────
const MeasuredChart = ({ height, pattern, cycles, timeLabels, highlight }) => {
  const [w, setW] = useState(0);

  return (
    <View
      style={[styles.chartBox, highlight && styles.highlightBox]}
      onLayout={(e) => setW(e.nativeEvent.layout.width)}
    >
      <ECGChart
        width={w}
        height={height}
        pattern={pattern}
        cycles={cycles}
        timeLabels={timeLabels}
      />

      {/* Dimension label ONLY (no M bubble) */}
      {highlight && (
        <View style={styles.dimensionTag}>
          <Text style={styles.dimensionText}>96.78 × 135.49</Text>
        </View>
      )}
    </View>
  );
};

const CustomRightPanel = () => {
  const insets = useSafeAreaInsets();

  return (
    <View style={styles.rightPanel}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={{ paddingTop: insets.top + 8 }}>
          {/* ECG BOX */}
          <View style={styles.measureCard}>
            <Text style={styles.rightTitle}>ECG Measurements</Text>

            <View style={styles.measureGrid}>
              <View style={styles.measureCol}>
                <Text style={styles.measure}>
                  HR: <Text style={styles.bold}>81 bpm</Text>
                </Text>
                <Text style={styles.measure}>
                  PR: <Text style={styles.bold}>164 ms</Text>
                </Text>
                <Text style={styles.measure}>
                  QT: <Text style={styles.bold}>448 ms</Text>
                </Text>
                <Text style={styles.measure}>
                  ST-II: <Text style={styles.bold}>+2.4 mm</Text>
                </Text>
                <Text style={styles.measure}>
                  P-amp: <Text style={styles.bold}>0.18 mV</Text>
                </Text>
                <Text style={styles.measure}>
                  T-inv: <Text style={styles.bold}>aVL, V1</Text>
                </Text>
              </View>

              <View style={styles.measureCol}>
                <Text style={styles.measure}>
                  Axis: <Text style={styles.bold}>+105°</Text>
                </Text>
                <Text style={styles.measure}>
                  QRS: <Text style={styles.bold}>92 ms</Text>
                </Text>
                <Text style={styles.measure}>
                  QTC: <Text style={styles.bold}>468 ms</Text>
                </Text>
                <Text style={styles.measure}>
                  ST-V5: <Text style={styles.bold}>+1.8 mm</Text>
                </Text>
                <Text style={styles.measure}>
                  R-amp: <Text style={styles.bold}>1.4 mV</Text>
                </Text>
                <Text style={styles.measure}>
                  Δ-wave: <Text style={styles.bold}>None</Text>
                </Text>
              </View>
            </View>
          </View>

          {/* AI ASSIST */}
          <View style={styles.aiSection}>
            <Text style={styles.aiHeader}>✦ AI Assist</Text>

            <View style={[styles.aiCard, { backgroundColor: "#FDECEC" }]}>
              <Text style={styles.aiTitle}>
                Inferior STEMI pattern — leads II, III, aVF
              </Text>
              <Text style={styles.aiSub}>
                ST elevation ≥2mm with reciprocal depression in aVL
              </Text>
            </View>

            <View style={[styles.aiCard, { backgroundColor: "#FFF4E5" }]}>
              <Text style={styles.aiTitle}>QTc prolongation — 468 ms</Text>
              <Text style={styles.aiSub}>
                Risk of Torsades. Avoid QT-prolonging medications
              </Text>
            </View>

            <View style={[styles.aiCard, { backgroundColor: "#E3F2FD" }]}>
              <Text style={styles.aiTitle}>Right axis deviation (+105°)</Text>
              <Text style={styles.aiSub}>
                May suggest RV strain or posterior involvement
              </Text>
            </View>

            <View style={[styles.aiCard, { backgroundColor: "#F3E5F5" }]}>
              <Text style={styles.aiTitle}>T-wave inversion in aVL, V1</Text>
              <Text style={styles.aiSub}>
                Reciprocal changes consistent with inferior event
              </Text>
            </View>

            <View style={[styles.aiCard, { backgroundColor: "#E8F5E9" }]}>
              <Text style={styles.aiTitle}>
                No ventricular ectopics detected
              </Text>
              <Text style={styles.aiSub}>
                QRS morphology normal. No bundle branch block
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

// ─── Main screen ─────────────────────────────────────────────────────────────
export default function ECGScreen({ navigation }) {
    return (
      
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" />

      <View style={styles.root}>
        <Sidebar navigation={navigation} />

        <View style={styles.main}>
          <DetailedTopBar navigation={navigation} />

          <ScrollView>
            <View style={styles.formContainer}>
              <View style={styles.titleRow}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.title}>
                    Sinus Rhythm – ♥ 77 BPM Average
                  </Text>
                  <Text style={styles.subtitle}>
                    This ECG does not show signs of atrial fibrillation.
                  </Text>
                </View>

                <Text style={styles.recordedText}>
                  Recorded on 7 Aug 2024 at 10:23
                </Text>
              </View>

              {/* MAIN STRIP */}
              <MeasuredChart
                height={160}
                pattern="normal"
                cycles={9}
                highlight
                timeLabels={[
                  "0s",
                  "1s",
                  "2s",
                  "3s",
                  "4s",
                  "5s",
                  "6s",
                  "7s",
                  "8s",
                ]}
              />

              <View style={styles.leadHeaderRow}>
                <Text style={styles.section}>12 Lead Overview</Text>

                <View style={styles.leadBadgeRow}>
                  <Text style={styles.leadBadge}>Auto-gain</Text>
                  <Text style={styles.dot}>·</Text>
                  <Text style={styles.leadBadge}>25mm/s</Text>
                  <Text style={styles.dot}>·</Text>
                  <Text style={styles.leadBadge}>10mm/mV</Text>
                  <Text style={styles.dot}>·</Text>
                  <Text style={[styles.leadBadge, { color: "#666" }]}>OK</Text>
                  <Text style={styles.dot}>·</Text>
                  <Text style={styles.leadBadge}>Artifact</Text>
                </View>
              </View>

              {[1, 2, 3].map((i) => (
                <MeasuredChart
                  key={i}
                  height={100}
                  pattern="normal"
                  cycles={9}
                />
              ))}
            </View>
          </ScrollView>
        </View>

        <CustomRightPanel />
      </View>
    </SafeAreaView>
  );
}

// ─── Styles ─────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F4F6FA" },
  root: { flex: 1, flexDirection: "row" },
  main: { flex: 1, backgroundColor: "#fff" },

  formContainer: { padding: 16 },

  title: { fontSize: 16, fontWeight: "700", color: "black" },
  subtitle: { fontSize: 12, color: "#666", marginBottom: 10 },

  chartBox: {
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#E0E0E0",
    overflow: "hidden",
    marginBottom: 12,
  },

  highlightBox: {
    borderStyle: "dashed",
    borderColor: "#4A90E2",
  },

  dimensionTag: {
    position: "absolute",
    bottom: 5,
    left: 5,
    backgroundColor: "#4A90E2",
    paddingHorizontal: 6,
    borderRadius: 4,
  },

  dimensionText: {
    color: "#fff",
    fontSize: 10,
  },

  section: {
    fontSize: 14,
    fontWeight: "700",
    marginTop: 10,
    color: "black",
  },

  rightPanel: {
    width: 300,
    backgroundColor: "#fff",
    borderLeftWidth: 1,
    borderLeftColor: "#E8ECF2",
    padding: 10,
  },

  rightTitle: {
    fontWeight: "800",
    marginBottom: 10,
    color: "#1F2024",
    fontSize: 16,
  },

  measure: {
    fontSize: 12,
    marginBottom: 4,
    fontWeight: 400,
    color: "#000000",
  },

  bold: {
    fontWeight: "700",
  },

  aiCard: {
    marginTop: 10,
    backgroundColor: "#FFECEC",
    padding: 8,
    borderRadius: 6,
  },

  aiTitle: {
    fontWeight: "700",
    fontSize: 12,
  },

  aiSub: {
    fontSize: 11,
  },

  measureGrid: {
    flexDirection: "row",
    justifyContent: "space-between",
  },

  measureCol: {
    flex: 1,
  },

  measure: {
    fontSize: 12,
    color: "#111",
    marginBottom: 6,
  },

  bold: {
    fontWeight: "700",
  },
  titleRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 10,
  },

  recordedText: {
    fontSize: 10,
    color: "#999",
    marginTop: 32,
  },

  leadHeaderRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
  },

  leadBadgeRow: {
    flexDirection: "row",
    alignItems: "center",
    flexWrap: "wrap",
  },

  leadBadge: {
    fontSize: 10,
    color: "#666",
  },

  dot: {
    marginHorizontal: 3,
    color: "#bbb",
  },

  measureCard: {
    backgroundColor: "#F4F6FA",
    padding: 12,
    borderRadius: 10,
    marginBottom: 10,
  },

  aiSection: {
    marginTop: 6,
  },

  aiHeader: {
    fontWeight: "700",
    fontSize: 13,
    marginBottom: 8,
  },

  aiCard: {
    borderRadius: 8,
    padding: 8,
    marginBottom: 6,
  },

  aiTitle: {
    fontSize: 11,
    fontWeight: "700",
    color: "#1F2024",
  },

  aiSub: {
    fontSize: 10,
    color: "#555",
  },
});
