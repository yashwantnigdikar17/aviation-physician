// components/NotificationPanel.js
import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import MaterialIcons from "react-native-vector-icons/MaterialIcons";

const NotificationPanel = ({
  visible,
  onClose,
  notifications,
}) => {
  if (!visible) return null;

  // ✅ fallback (your existing static data)
  const data = notifications || [
    {
      title: "TODAY",
      items: [1, 2, 3],
    },
    {
      title: "12 March 2026",
      items: [1, 2, 3],
    },
  ];

  return (
    <View style={styles.overlay}>
      {/* Background */}
      <TouchableOpacity style={styles.overlayBg} onPress={onClose} />

      {/* Drawer */}
      <View style={styles.drawer}>
        {/* Header */}
        <View style={styles.drawerHeader}>
          <Text style={styles.drawerTitle}>Notification</Text>
          <TouchableOpacity onPress={onClose}>
            <MaterialIcons name="close" size={20} color="#1F2024" />
          </TouchableOpacity>
        </View>

        {/* Sections */}
        {data.map((section, index) => (
          <View key={index}>
            <Text style={styles.sectionTag}>{section.title}</Text>

            {section.items.map((_, i) => (
              <View key={i} style={styles.alertCard}>
                <View style={styles.alertIcon}>
                  <Text style={styles.alertIconText}>!</Text>
                </View>

                <View style={{ flex: 1 }}>
                  <Text style={styles.alertTitle}>Alert Headline</Text>
                  <Text style={styles.alertDesc}>
                    Description. Lorem ipsum dolor sit amet.
                  </Text>
                </View>

                <MaterialIcons
                  name="close"
                  size={16}
                  color="#727272"
                />
              </View>
            ))}
          </View>
        ))}
      </View>
    </View>
  );
};

export default NotificationPanel;


// ─────────────────────────────────────────────
// STYLES
// ─────────────────────────────────────────────
const styles = StyleSheet.create({
  overlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 999,
    flexDirection: "row",
  },

  overlayBg: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.3)",
  },

  drawer: {
    width: 320,
    backgroundColor: "#fff",
    padding: 16,
  },

  drawerHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },

  drawerTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#1F2024",
  },

  sectionTag: {
    fontSize: 11,
    fontWeight: "600",
    color: "#9CA3AF",
    marginTop: 10,
    marginBottom: 6,
  },

  alertCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#F6F9FF",
    borderRadius: 10,
    padding: 10,
    marginBottom: 8,
    gap: 8,
  },

  alertIcon: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: "#EF4444",
    alignItems: "center",
    justifyContent: "center",
  },

  alertIconText: {
    color: "#fff",
    fontWeight: "700",
  },

  alertTitle: {
    fontSize: 12,
    fontWeight: "600",
    color: "#1F2024",
  },

  alertDesc: {
    fontSize: 10,
    color: "#6B7280",
  },
});