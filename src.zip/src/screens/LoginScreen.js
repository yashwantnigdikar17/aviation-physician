import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, StatusBar, Platform, Image,
  useWindowDimensions, ScrollView,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Logo from '../assets/Images/tiatelelogo.svg';

/* ─── Breakpoints ─────────────────────────────────────────────────────────── */
const BREAKPOINTS = {
  phone:  600,   // < 600  → stacked (single column)
  tablet: 900,   // 600–900 → tablet portrait (stacked but wider padding)
               // > 900  → side-by-side (original layout)
};

/* ─── Sub-components ─────────────────────────────────────────────────────── */
const InputField = ({ label, value, onChangeText, placeholder, secureTextEntry }) => (
  <View style={styles.inputWrapper}>
    <Text style={styles.label}>{label}</Text>
    <TextInput
      style={styles.input}
      value={value}
      onChangeText={onChangeText}
      placeholder={placeholder}
      placeholderTextColor="#aaa"
      secureTextEntry={secureTextEntry}
      autoCapitalize="none"
    />
  </View>
);

const FeatureItem = ({ icon, subtitle }) => (
  <View style={styles.featureItem}>
    
    <Image
      source={icon}
      style={styles.featureIconImage}
      resizeMode="contain"
    />

    <Text style={styles.featureText}>
      {subtitle}
    </Text>

  </View>
);

/* ─── Main Screen ─────────────────────────────────────────────────────────── */
export default function LoginScreen({ navigation }) {
  const [companyName, setCompanyName]   = useState('Qantas Airlines');
  const [tailNumber, setTailNumber]     = useState('N12345');
  const [flightNumber, setFlightNumber] = useState('QA-B737');
  const [secureCode, setSecureCode]     = useState('12345');
  const [email, setEmail] = useState('dr.johnson@telecare.com');
const [password, setPassword] = useState('QA-B737');
  const { width, height } = useWindowDimensions();

  /* Derive layout mode */
  const isLandscape  = width > height;
  const isWide       = width > BREAKPOINTS.tablet;           // side-by-side
  const isMid        = width > BREAKPOINTS.phone && !isWide; // tablet portrait
  const isPhone      = width <= BREAKPOINTS.phone;           // phone

  /* On phones / tablet-portrait → stacked; on wide → row */
  const layoutRow    = isWide;

  /* Responsive horizontal padding for left panel */
  const hPad = isPhone ? '5%' : isMid ? '8%' : '6%';

const handleLogin = () => {
    if (!email.trim()) {
      Alert.alert('Error', 'Please enter your email address');
      return;
    }
    if (!password.trim()) {
      Alert.alert('Error', 'Please enter your password');
      return;
    }
    if (email === 'dr.johnson@telecare.com' && password === 'QA-B737') {
      console.log('Login successful', { email, password });
      navigation.replace('AllEvent');
    } else {
      Alert.alert('Login Failed', 'Invalid email or password. Please try again.');
    }
  };

  const handleForgotPassword = () => {
    Alert.alert(
      'Reset Password',
      'Instructions to reset your password will be sent to your registered email address.',
      [{ text: 'OK', onPress: () => console.log('OK Pressed') }]
    );
  };

  /* ── Left (form) panel ── */
  const LeftPanel = (
    <View
      style={[
        styles.leftPanel,
        {
          flex: layoutRow ? 0.85 : 1,
          paddingHorizontal: hPad,
          // On stacked layouts give fixed padding, not flex-based centering
          paddingVertical: isPhone ? 32 : isMid ? 36 : 24,
        },
      ]}
    >
      <View style={styles.logoRow}>
        <View style={styles.logoIcon}>
          <Logo width={76} height={100} />
        </View>
        <Text style={styles.logoText}>
          Tia<Text style={styles.logoTextAccent}>TELE</Text>
        </Text>
      </View>

<Text style={styles.heading}>Telecare Provider Portal</Text>
<Text style={styles.subheading}>
  Please enter the below details to login
</Text>

<InputField
  label="Email"
  value={email}
  onChangeText={setEmail}
  placeholder="Enter your email"
/>

<InputField
  label="Password"
  value={password}
  onChangeText={setPassword}
  placeholder="Enter your password"
  secureTextEntry
      />
      
      <Text style={styles.forgot}>Forgot Password?</Text>

<TouchableOpacity style={styles.loginBtn} onPress={handleLogin}>
  <Text style={styles.loginBtnText}>Login</Text>
</TouchableOpacity>
     
    </View>

  );

  /* ── Right (hero) panel ── */
  const RightPanel = (
    <View
      style={[
        styles.rightPanel,
        {
          flex: layoutRow ? 1.15 : 1,
          // On stacked layout give a fixed height instead of flex fill
          minHeight: layoutRow ? undefined : isPhone ? 320 : 380,
          maxHeight: layoutRow ? undefined : isPhone ? 380 : 460,
        },
      ]}
    >
      <Image
        source={require('../assets/Images/doctor-patient.png')}
        style={[
          styles.fullImage,
          { height: layoutRow ? '75%' : '85%' },
        ]}
        resizeMode="stretch"
      />

      <LinearGradient
        colors={[
          'transparent',
          'transparent',
          'rgba(21, 101, 192, 0.05)',
          'rgba(21, 101, 192, 0.15)',
          'rgba(21, 101, 192, 0.30)',
          'rgba(21, 101, 192, 0.50)',
          'rgba(21, 101, 192, 0.93)',
          'rgba(21, 101, 192, 0.93)',
          'rgba(21, 101, 192,0.99)',
          '#1565C0ED',
          '#1565C0ED',
        ]}
        locations={[0, 0.30, 0.38, 0.44, 0.50, 0.56, 0.62, 0.68, 0.73, 0.78, 1]}
        style={styles.gradientLayer}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
      />

      <View
        style={[
          styles.contentSection,
          {
            paddingBottom: layoutRow ? 90 : isPhone ? 24 : 36,
            paddingHorizontal: layoutRow ? 24 : isPhone ? 16 : 32,
          },
        ]}
      >
        <Text style={[styles.rightHeading, isPhone && { fontSize: 22, lineHeight: 26 }]}>
          Real-Time Medical Support,{'\n'}When It Matters Most
        </Text>
        <Text style={styles.rightSubheading}>
          Empowering you with instant physician guidance to handle {'\n'} onboard
          medical emergencies with confidence
        </Text>
        <View style={styles.featuresRow}>
  <FeatureItem 
            icon={require('../assets/Images/Safety.png')}
            // title="24/7 access"
            subtitle={`24/7 access\n to qualified\n physicians`}
  />

  <FeatureItem 
    icon={require('../assets/Images/Safety.png')}
    // title="Instant"
    subtitle={`Instant\n tele-assistance\n for emergencies`}
  />

  <FeatureItem 
    icon={require('../assets/Images/Safety.png')}
    // title="Guided"
    subtitle={`Guided\n decision-making\n for critical care`}
  />
</View>
        <View style={styles.dots}>
          {[0, 1, 2, 3].map(i => (
            <View key={i} style={[styles.dot, i === 2 && styles.dotActive]} />
          ))}
        </View>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <StatusBar
  barStyle="light-content"   // 👈 white icons
  backgroundColor="rgba(0,0,0,1)" // 👈 pure black
/>

      {layoutRow ? (
        /* ── Wide (tablet landscape / desktop) — side by side ── */
        <View style={styles.mainRow}>
          {LeftPanel}
          {RightPanel}
        </View>
      ) : (
        /* ── Narrow (phone / tablet portrait) — stacked with scroll ── */
        <ScrollView
          contentContainerStyle={styles.stackedContainer}
          keyboardShouldPersistTaps="handled"
          bounces={false}
        >
          {RightPanel}
          {LeftPanel}
        </ScrollView>
      )}
    </View>
  );
}

/* ─── Styles (unchanged from original except where noted) ─────────────────── */
const styles = StyleSheet.create({
  container:        { flex: 1, backgroundColor: '#fff' },
  mainRow:          { flex: 1, flexDirection: 'row' },
  stackedContainer: { flexGrow: 1 },   // ← new: enables ScrollView stacking

  /* LEFT PANEL */
  leftPanel: {
    backgroundColor: '#fff',
    justifyContent: 'center',
  },
  logoRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 32 },
  featureIconImage: {
  width: 56,
  height: 56,
  tintColor: '#fff', // 👈 makes icon white (optional)
},
  logoIcon: {
    width: 90, height: 96, borderRadius: 32, overflow: 'hidden',
    marginRight: 12, backgroundColor: '#fff',
    justifyContent: 'center', alignItems: 'center',
    paddingRight: 20, paddingLeft: 20,
  },
  logoImage:     { width: 110, height: 110, resizeMode: 'contain' },
  logoText:      { fontSize: 30, fontWeight: '800', color: '#0f1012', lineHeight: 40 },
  logoTextAccent:{ color: '#1565C0', fontWeight: '800', letterSpacing: 1 },
  heading:       { fontSize: 17, fontWeight: '700', color: '#111', marginBottom: 4 },
  subheading:    { fontSize: 12, color: '#666', marginBottom: 22 },
  formRow:       { flexDirection: 'row', marginBottom: 4 },
  formCol:       { flex: 1 },
  formColGap:    { width: 12 },
  inputWrapper:  { marginBottom: 14 },
  label:         { fontSize: 12, color: '#444', marginBottom: 5, fontWeight: '500' },
  input: {
    borderWidth: 1, borderColor: '#ddd', borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: Platform.OS === 'ios' ? 10 : 9,
    fontSize: 13, color: '#333', backgroundColor: '#fafafa',
  },
  loginBtn:     { backgroundColor: '#1565C0', borderRadius: 8, paddingVertical: 13, alignItems: 'center', marginTop: 6 },
  loginBtnText: { color: '#fff', fontSize: 15, fontWeight: '700', letterSpacing: 0.5 },

  /* RIGHT PANEL */
  rightPanel:   { overflow: 'hidden', backgroundColor: '#1565C0ED' },
  fullImage: {
    position: 'absolute', top: 0, left: 0, right: 0,
    width: '100%',
  },
  gradientLayer: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 },
contentSection: {
  position: 'absolute',
  bottom: -60,   // 👈 pushes everything DOWN
  left: 0,
  right: 0,
  paddingTop: 24,
  paddingHorizontal: 32,
  paddingBottom: 80, // 👈 extra breathing space
},
  rightHeading: {
  color: '#fff',
  fontSize: 30,
  fontWeight: '800',
  textAlign: 'center',
  lineHeight: 36,
  marginBottom: 14,
},
 rightSubheading: {
  color: 'rgba(255,255,255,0.9)',
  fontSize: 11,
  textAlign: 'center',
  lineHeight: 20,
  marginBottom: 28,
   paddingHorizontal: 20,
  fontWeight:500
},
 featuresRow: {
  flexDirection: 'row',
  justifyContent: 'space-between',
  marginBottom: 24,
},
  featureItem: {
  flex: 1,
  flexDirection: 'row',   // 👈 side-by-side
  alignItems: 'center',
  gap: 8,                 // spacing between icon & text
    paddingHorizontal: 6,
  marginLeft:12,
},

featureIconImage: {
  width: 28,   // 👈 bigger icon
  height: 28,
  tintColor: '#fff',
  },
featureText: {
  flex: 1,
  color: '#fff',
  fontSize: 10,
  fontWeight:400,
  lineHeight: 16,
},
  featureTitle:   { color: '#fff', fontSize: 11, fontWeight: '700', textAlign: 'center' },
 featureSubtitle: {
  color: 'rgba(255,255,255,0.85)',
   fontSize: 11,
  fontWeight:500,
  textAlign: 'center',
  lineHeight: 16,
},
  dots:           { flexDirection: 'row', justifyContent: 'center', gap: 6 },
  dot:            { width: 7, height: 7, borderRadius: 4, backgroundColor: 'rgba(255,255,255,0.35)' },
  dotActive: { backgroundColor: '#fff', width: 20 },
  forgot: {
  color: '#1565C0',
  textAlign: 'right',
  fontSize: 12,
  marginBottom: 12,
},
});