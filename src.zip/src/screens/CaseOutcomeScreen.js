/**
 * CaseOutcomeScreen.js
 * React Native CLI — Case Outcome & Final Report
 *
 * Dependencies (install before use):
 *   npm install react-native-svg
 *   cd ios && pod install   (iOS only)
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  Dimensions,
} from 'react-native';
import Svg, { Polyline } from 'react-native-svg';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const SIDEBAR_WIDTH = 72;

// ─── Colour Tokens ──────────────────────────────────────────────────────────
const C = {
  primary: '#1A6EE4',
  primaryLight: '#EBF2FD',
  success: '#22C55E',
  successLight: '#DCFCE7',
  warning: '#F97316',
  warningLight: '#FFF7ED',
  danger: '#EF4444',
  dangerLight: '#FEF2F2',
  bg: '#F4F6FA',
  card: '#FFFFFF',
  border: '#E5E9F0',
  textPrimary: '#111827',
  textSecondary: '#6B7280',
  textMuted: '#9CA3AF',
  sidebar: '#FFFFFF',
  sidebarActive: '#EBF3FF',
  sidebarIcon: '#6B7280',
  sidebarIconActive: '#1A6EE4',
};

// ─── Data ────────────────────────────────────────────────────────────────────
const caseLeftRows = [
  { label: 'Flight Number', value: 'AA123 (JFK → LAX)' },
  { label: 'Case ID', value: 'TC-20260127-AA123-001' },
  { label: 'Time of Onset', value: '14:35 UTC' },
  { label: 'Case Duration', value: '45 minutes' },
  { label: 'Patient', value: 'Male, 42 years, Seat 15A' },
];

const caseRightRows = [
  { label: 'Primary Complaint', value: 'Neurologic - Left-sided weakness' },
  { label: 'Interventions', value: 'O2 (2L/min), Aspirin, Analgesic' },
  { label: 'Medical Volunteer', value: 'Doctor - Dr. Sarah Mitchell' },
  { label: 'Ground Support', value: 'Contacted - No diversion advised' },
  { label: 'Final Status', value: 'Stabilised - Monitoring continued' },
];

const aiSummaryText = [
  'The patient, a 42-year-old male, presented with acute onset of left-sided weakness at 14:35 UTC during flight AA123. The medical volunteer, Dr. Sarah Mitchell, assessed the patient promptly and initiated appropriate interventions including supplemental oxygen at 2L/min, Aspirin, and Analgesic administration.',
  "Ground support was contacted and after thorough evaluation, no flight diversion was deemed necessary. The patient's condition stabilised throughout the flight with continuous monitoring. Vital signs remained within acceptable parameters with the exception of oxygen saturation requiring supplementation.",
  'The case was managed effectively within the in-flight medical protocol. Patient monitoring was continued until landing. All interventions and outcomes have been documented for handover to ground medical personnel upon arrival at LAX.',
];

// ─── ECG Waveform ─────────────────────────────────────────────────────────
const ECG_POINTS =
  '0,20 5,20 8,20 10,5 12,35 14,20 20,20 25,20 28,20 30,5 32,35 34,20 40,20 45,20 48,20 50,5 52,35 54,20 60,20 65,20 68,20 70,5 72,35 74,20 80,20';

const EcgChart = () => (
  <Svg height={40} width={85}>
    <Polyline
      points={ECG_POINTS}
      fill="none"
      stroke={C.danger}
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </Svg>
);

// ─── Vital Card ───────────────────────────────────────────────────────────
const VitalCard = ({ label, value, unit, alert, icon, showEcg }) => {
  const borderColor =
    alert === 'danger' ? C.danger : alert === 'warning' ? C.warning : 'transparent';
  const hasBorder = !!alert;

  return (
    <View
      style={[
        styles.vitalCard,
        hasBorder && { borderLeftWidth: 3, borderLeftColor: borderColor },
      ]}
    >
      <View style={styles.vitalTop}>
        <Text style={styles.vitalLabel}>{label}</Text>
        <Text style={styles.vitalIcon}>{icon}</Text>
      </View>

      {showEcg ? (
        <View style={styles.vitalEcgRow}>
          <Text
            style={[
              styles.vitalValue,
              alert === 'danger' && { color: C.danger },
              alert === 'warning' && { color: C.warning },
            ]}
          >
            {value}
          </Text>
          <EcgChart />
        </View>
      ) : (
        <Text
          style={[
            styles.vitalValue,
            alert === 'danger' && { color: C.danger },
            alert === 'warning' && { color: C.warning },
          ]}
        >
          {value}
          {unit && <Text style={styles.vitalUnit}> {unit}</Text>}
        </Text>
      )}
    </View>
  );
};

// ─── Sidebar Item ─────────────────────────────────────────────────────────
const SidebarItem = ({ icon, label, active }) => (
  <TouchableOpacity style={[styles.sidebarItem, active && styles.sidebarItemActive]}>
    <Text style={styles.sidebarIcon}>{icon}</Text>
    <Text
      style={[styles.sidebarLabel, active && styles.sidebarLabelActive]}
      numberOfLines={1}
    >
      {label}
    </Text>
  </TouchableOpacity>
);

// ─── Main Screen ──────────────────────────────────────────────────────────
const CaseOutcomeScreen = () => {
  const [synced] = useState('Today 12:00 PM');

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" backgroundColor={C.card} />

      <View style={styles.root}>

        {/* ── Sidebar ── */}
        <View style={styles.sidebar}>
          {/* Logo */}
          <View style={styles.logoContainer}>
            <View style={styles.logoBox}>
              <Text style={styles.logoText}>T</Text>
            </View>
            <Text style={styles.logoSub}>TiaTELE</Text>
          </View>

          {/* Nav Items */}
          <View style={styles.sidebarNav}>
            <SidebarItem icon="📋" label="All Events" active />
            <SidebarItem icon="🔍" label="Search Kit" />
            <SidebarItem icon="❓" label="FAQs" />
            <SidebarItem icon="✨" label="Tia AI" />
            <SidebarItem icon="🔔" label="Alerts" />
          </View>

          {/* Bottom Items */}
          <View style={styles.sidebarBottom}>
            <SidebarItem icon="↪️" label="Logout" />
            <SidebarItem icon="⚙️" label="Settings" />
          </View>
        </View>

        {/* ── Main Content ── */}
        <View style={styles.main}>

          {/* Header */}
          <View style={styles.header}>
            <View style={styles.headerLeft}>
              <View style={styles.deviceBadge}>
                <View style={styles.dot} />
                <Text style={styles.deviceBadgeText}>Device Connect</Text>
              </View>
              <View style={styles.syncBadge}>
                <Text style={styles.syncText}>🔄 Last synced {synced}</Text>
              </View>
            </View>

            <View style={styles.headerRight}>
              <TouchableOpacity style={styles.joinBtn}>
                <Text style={styles.joinBtnText}>📹  Join Now</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.bellBtn}>
                <Text style={styles.bellIcon}>🔔</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Scrollable Content */}
          <ScrollView
            style={styles.scrollArea}
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator={false}
          >
            {/* Page Title */}
            <Text style={styles.pageTitle}>Case Outcome & Final Report</Text>
            <Text style={styles.pageSubtitle}>
              Choose the option that best describes what happened, this will be
              the official record for the medical team.
            </Text>

            {/* Action Buttons */}
            <View style={styles.actionRow}>
              <TouchableOpacity style={styles.btnPrimary}>
                <Text style={styles.btnPrimaryText}>Generate Full Report PDF</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.btnOutline}>
                <Text style={styles.btnOutlineText}>Email Final Report</Text>
              </TouchableOpacity>
            </View>

            {/* ── Case Summary Card ── */}
            <View style={styles.card}>
              <Text style={styles.cardTitle}>Case Summary for John Smith</Text>
              <View style={styles.caseGrid}>
                {/* Left Column */}
                <View style={styles.caseCol}>
                  {caseLeftRows.map((row, i) => (
                    <View key={i} style={styles.caseRow}>
                      <Text style={styles.caseLabel}>{row.label}</Text>
                      <Text style={styles.caseValue}>{row.value}</Text>
                    </View>
                  ))}
                </View>

                {/* Divider */}
                <View style={styles.caseDivider} />

                {/* Right Column */}
                <View style={styles.caseCol}>
                  {caseRightRows.map((row, i) => (
                    <View key={i} style={styles.caseRow}>
                      <Text style={styles.caseLabel}>{row.label}</Text>
                      <Text style={styles.caseValue}>{row.value}</Text>
                    </View>
                  ))}
                </View>
              </View>
            </View>

            {/* ── AI Summary Card ── */}
            <View style={styles.card}>
              <View style={styles.aiTitleRow}>
                <Text style={styles.aiSparkle}>✦</Text>
                <Text style={styles.aiTitle}>AI summary of the event</Text>
              </View>
              {aiSummaryText.map((para, i) => (
                <Text key={i} style={styles.aiPara}>
                  {para}
                </Text>
              ))}
            </View>

            {/* ── Patient Vitals Card ── */}
            <View style={styles.card}>
              <View style={styles.vitalsHeader}>
                <Text style={styles.vitalsTitle}>Patient Vitals</Text>
                <Text style={styles.vitalsUpdated}>
                  Last updated 20/04/2026 12:55:54
                </Text>
              </View>

              <View style={styles.vitalsGrid}>
                <VitalCard label="Heart Rate"        value="88 bpm"      icon="🫀" />
                <VitalCard label="Blood Pressure"    value="135/85 mmHg" icon="🩺" />
                <VitalCard label="Heart Rate"        value="88 bpm"      icon="🫀" />
                <VitalCard label="Oxygen"            value="80%"         icon="💨" alert="danger" />
                <VitalCard label="Respiratory rate"  value="24 mins."    icon="🫁" />
                <VitalCard label="Temperature"       value="34.5 C"      icon="🌡️" alert="warning" />
                <VitalCard label="Skin Colour"       value="Normal"      icon="👤" />
                <VitalCard label="Sweating"          value="Mild"        icon="💧" />
                <VitalCard label="ECG"               value="Sinus"       icon="📈" showEcg alert="danger" />
                <VitalCard label="Pain Score"        value="6/10"        icon="😣" />
                <VitalCard label="Blood Glucose"     value="100 mg/dl"   icon="🩸" />
                <VitalCard label="AVPU Score"        value="15"          icon="🙂" />
              </View>
            </View>
          </ScrollView>
        </View>
      </View>
    </SafeAreaView>
  );
};

// ─── Styles ───────────────────────────────────────────────────────────────
const VITAL_COLUMNS = 4;
const VITALS_PADDING = 18 * 2;
const VITALS_GAP = 10 * (VITAL_COLUMNS - 1);
const VITAL_CARD_WIDTH =
  (SCREEN_WIDTH - SIDEBAR_WIDTH - 20 * 2 - VITALS_PADDING - VITALS_GAP) / VITAL_COLUMNS;

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: C.card,
  },
  root: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: C.bg,
  },

  // ── Sidebar ──────────────────────────────────────────────────────────────
  sidebar: {
    width: SIDEBAR_WIDTH,
    backgroundColor: C.sidebar,
    borderRightWidth: 1,
    borderRightColor: C.border,
    justifyContent: 'space-between',
    paddingVertical: 16,
  },
  logoContainer: {
    alignItems: 'center',
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: C.border,
    marginBottom: 8,
  },
  logoBox: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: C.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoText: {
    color: '#FFFFFF',
    fontWeight: '800',
    fontSize: 18,
  },
  logoSub: {
    fontSize: 8,
    color: C.textSecondary,
    marginTop: 3,
    fontWeight: '600',
  },
  sidebarNav: {
    flex: 1,
  },
  sidebarItem: {
    alignItems: 'center',
    paddingVertical: 10,
    marginHorizontal: 6,
    borderRadius: 10,
    marginBottom: 2,
  },
  sidebarItemActive: {
    backgroundColor: C.sidebarActive,
  },
  sidebarIcon: {
    fontSize: 20,
  },
  sidebarLabel: {
    fontSize: 9,
    color: C.textSecondary,
    marginTop: 3,
    textAlign: 'center',
  },
  sidebarLabelActive: {
    color: C.primary,
    fontWeight: '600',
  },
  sidebarBottom: {
    borderTopWidth: 1,
    borderTopColor: C.border,
    paddingTop: 8,
  },

  // ── Main ─────────────────────────────────────────────────────────────────
  main: {
    flex: 1,
    backgroundColor: C.bg,
  },

  // ── Header ───────────────────────────────────────────────────────────────
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: C.card,
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: C.border,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  deviceBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: C.successLight,
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 5,
    gap: 5,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: C.success,
  },
  deviceBadgeText: {
    fontSize: 12,
    color: '#15803D',
    fontWeight: '600',
  },
  syncBadge: {
    paddingHorizontal: 8,
    paddingVertical: 5,
  },
  syncText: {
    fontSize: 12,
    color: C.textSecondary,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  joinBtn: {
    backgroundColor: C.primary,
    borderRadius: 8,
    paddingHorizontal: 14,
    paddingVertical: 7,
  },
  joinBtnText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 13,
  },
  bellBtn: {
    width: 36,
    height: 36,
    borderRadius: 8,
    backgroundColor: C.bg,
    borderWidth: 1,
    borderColor: C.border,
    justifyContent: 'center',
    alignItems: 'center',
  },
  bellIcon: {
    fontSize: 16,
  },

  // ── Scroll Area ───────────────────────────────────────────────────────────
  scrollArea: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    gap: 16,
    paddingBottom: 32,
  },

  // ── Page Heading ──────────────────────────────────────────────────────────
  pageTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: C.textPrimary,
    letterSpacing: -0.5,
  },
  pageSubtitle: {
    fontSize: 13,
    color: C.textSecondary,
    lineHeight: 19,
    marginTop: 4,
  },

  // ── Action Buttons ────────────────────────────────────────────────────────
  actionRow: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 4,
    flexWrap: 'wrap',
  },
  btnPrimary: {
    backgroundColor: C.primary,
    borderRadius: 8,
    paddingHorizontal: 18,
    paddingVertical: 10,
  },
  btnPrimaryText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 13,
  },
  btnOutline: {
    borderWidth: 1.5,
    borderColor: C.primary,
    borderRadius: 8,
    paddingHorizontal: 18,
    paddingVertical: 10,
  },
  btnOutlineText: {
    color: C.primary,
    fontWeight: '700',
    fontSize: 13,
  },

  // ── Card ──────────────────────────────────────────────────────────────────
  card: {
    backgroundColor: C.card,
    borderRadius: 14,
    padding: 18,
    borderWidth: 1,
    borderColor: C.border,
  },
  cardTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: C.textPrimary,
    marginBottom: 14,
  },

  // ── Case Summary ──────────────────────────────────────────────────────────
  caseGrid: {
    flexDirection: 'row',
  },
  caseCol: {
    flex: 1,
    gap: 10,
  },
  caseDivider: {
    width: 1,
    backgroundColor: C.border,
    marginHorizontal: 16,
    alignSelf: 'stretch',
  },
  caseRow: {
    gap: 2,
  },
  caseLabel: {
    fontSize: 11,
    color: C.textSecondary,
    fontWeight: '400',
  },
  caseValue: {
    fontSize: 13,
    color: C.textPrimary,
    fontWeight: '700',
  },

  // ── AI Summary ────────────────────────────────────────────────────────────
  aiTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    marginBottom: 12,
  },
  aiSparkle: {
    fontSize: 16,
    color: C.primary,
  },
  aiTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: C.textPrimary,
  },
  aiPara: {
    fontSize: 13,
    color: C.textSecondary,
    lineHeight: 20,
    marginBottom: 10,
  },

  // ── Patient Vitals ────────────────────────────────────────────────────────
  vitalsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
    flexWrap: 'wrap',
    gap: 4,
  },
  vitalsTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: C.textPrimary,
  },
  vitalsUpdated: {
    fontSize: 11,
    color: C.textSecondary,
  },
  vitalsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  vitalCard: {
    backgroundColor: C.bg,
    borderRadius: 10,
    padding: 12,
    width: VITAL_CARD_WIDTH,
    minWidth: 110,
    borderWidth: 1,
    borderColor: C.border,
    gap: 4,
  },
  vitalTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  vitalLabel: {
    fontSize: 10,
    color: C.textSecondary,
    fontWeight: '500',
    flex: 1,
    flexWrap: 'wrap',
  },
  vitalIcon: {
    fontSize: 14,
  },
  vitalValue: {
    fontSize: 16,
    fontWeight: '700',
    color: C.textPrimary,
    marginTop: 4,
  },
  vitalUnit: {
    fontSize: 12,
    fontWeight: '400',
    color: C.textSecondary,
  },
  vitalEcgRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 4,
    flexWrap: 'wrap',
  },
});

export default CaseOutcomeScreen;