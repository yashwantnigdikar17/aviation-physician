// // screens/SearchKitScreen.js
// import React, { useState } from "react";
// import {
//   View,
//   Text,
//   StyleSheet,
//   TouchableOpacity,
//   TextInput,
//   ScrollView,
// } from "react-native";
// import MaterialIcons from "react-native-vector-icons/MaterialIcons";
// import Sidebar from "../components/Sidebar";
// import BlueMic from "../assets/Images/bluemic.svg";

// // 👉 Replace this with your SVG
// import KitPlaceholder from "../assets/Images/Designer.svg";

// export default function SearchKitScreen({ navigation }) {
//   const [activeTab, setActiveTab] = useState("medical");

//   return (
//       <View style={styles.root}>
//             {/* ✅ SIDEBAR */}
//         <Sidebar activeKey="searchKit" navigation={navigation} />

//       {/* LEFT SECTION */}
//       <View style={styles.leftPanel}>

//         {/* HEADER */}
//         <Text style={styles.title}>Find Medicine in Kit</Text>

//         {/* TOP CONTROLS */}
//         <View style={styles.topRow}>

//           {/* Tabs */}
//           <View style={styles.tabs}>
//             <TouchableOpacity
//               style={[
//                 styles.tabBtn,
//                 activeTab === "medical" && styles.tabActive,
//               ]}
//               onPress={() => setActiveTab("medical")}
//             >
//               <Text
//                 style={[
//                   styles.tabText,
//                   activeTab === "medical" && styles.tabTextActive,
//                 ]}
//               >
//                 Medical Kit
//               </Text>
//             </TouchableOpacity>

//             <TouchableOpacity
//               style={[
//                 styles.tabBtn,
//                 activeTab === "digital" && styles.tabInactive,
//               ]}
//               onPress={() => setActiveTab("digital")}
//             >
//               <Text style={styles.tabText}>Digital Kit</Text>
//             </TouchableOpacity>
//           </View>

//           {/* SEARCH */}
//          <View style={styles.searchBox}>
//   <MaterialIcons name="search" size={18} color="#0A5FFF" />

//   <TextInput
//     placeholder="Search"
//     placeholderTextColor="#9CA3AF"
//     style={styles.searchInput}
//   />

//   <BlueMic width={18} height={18} />
// </View>

//           {/* BUTTON */}
//           <TouchableOpacity style={styles.calcBtn}>
//             <MaterialIcons name="link" size={16} color="#fff" />
//             <Text style={styles.calcText}>Dosage Calculator</Text>
//           </TouchableOpacity>
//         </View>

//         {/* MODULE HEADER */}
//         <View style={styles.moduleHeader}>
//           <Text style={styles.moduleTitle}>💊 Module A (Essential):</Text>
//           <MaterialIcons name="keyboard-arrow-down" size={18} />
//         </View>

//         <Text style={styles.moduleDesc}>
//           Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
//         </Text>

//         {/* TABLE */}
// {/* TABLE */}
// <View style={styles.tableContainer}>

//   {/* HEADER */}
//   <View style={styles.tableHeader}>
//     <Text style={styles.th}>Name</Text>
//     <Text style={styles.th}>Usage</Text>
//   </View>

//   {/* ROWS */}
//   <ScrollView showsVerticalScrollIndicator={false}>
//     {DATA.map((item, index) => (
//       <View
//         key={index}
//         style={[
//           styles.row,
//           index === DATA.length - 1 && { borderBottomWidth: 0 }
//         ]}
//       >
//         <Text style={styles.name}>{item.name}</Text>
//         <Text style={styles.usage}>{item.usage}</Text>
//       </View>
//     ))}
//   </ScrollView>

// </View>
//       </View>

//       {/* RIGHT SECTION */}
//       <View style={styles.rightPanel}>
//         <KitPlaceholder width={160} height={160} />
//       </View>
//     </View>
//   );
// }

import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Modal,
} from "react-native";
import MaterialIcons from "react-native-vector-icons/MaterialIcons";
import Sidebar from "../components/Sidebar";
import BlueMic from "../assets/Images/bluemic.svg";
import KitPlaceholder from "../assets/Images/Designer.svg";

export default function SearchKitScreen({ navigation }) {
  const [activeTab, setActiveTab] = useState("medical");
  const [showModal, setShowModal] = useState(false);

  return (
    <View style={styles.root}>
      <Sidebar activeKey="searchKit" navigation={navigation} />

      <View style={styles.leftPanel}>
        <Text style={styles.title}>Find Medicine in Kit</Text>

        <View style={styles.topRow}>
          {/* Tabs */}
          <View style={styles.tabs}>
            <TouchableOpacity
              style={[
                styles.tabBtn,
                activeTab === "medical" && styles.tabActive,
              ]}
              onPress={() => setActiveTab("medical")}
            >
              <Text
                style={[
                  styles.tabText,
                  activeTab === "medical" && styles.tabTextActive,
                ]}
              >
                Medical Kit
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.tabBtn}
              onPress={() => setActiveTab("digital")}
            >
              <Text style={styles.tabText}>Digital Kit</Text>
            </TouchableOpacity>
          </View>

          {/* SEARCH */}
          <View style={styles.searchBox}>
            <MaterialIcons name="search" size={18} color="#0A5FFF" />
            <TextInput
              placeholder="Search"
              placeholderTextColor="#9CA3AF"
              style={styles.searchInput}
            />
            <BlueMic width={18} height={18} />
          </View>

          {/* BUTTON */}
          <TouchableOpacity
            style={styles.calcBtn}
            onPress={() => setShowModal(true)}
          >
            <MaterialIcons name="link" size={16} color="#fff" />
            <Text style={styles.calcText}>Dosage Calculator</Text>
          </TouchableOpacity>
              </View>
    <View style={styles.moduleContainer}>
               {/* MODULE HEADER */}
         <View style={styles.moduleHeader}>
           <Text style={styles.moduleTitle}>💊 Module A (Essential):</Text>
           <MaterialIcons name="keyboard-arrow-down" size={18} />
         </View>

         <Text style={styles.moduleDesc}>
           Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
/        </Text>

        {/* TABLE */}
        <View style={styles.tableContainer}>
          <View style={styles.tableHeader}>
            <Text style={styles.th}>Name</Text>
            <Text style={styles.th}>Usage</Text>
          </View>

          <ScrollView>
            {DATA.map((item, index) => (
              <View
                key={index}
                style={[
                  styles.row,
                  index === DATA.length - 1 && { borderBottomWidth: 0 },
                ]}
              >
                <Text style={styles.name}>{item.name}</Text>
                <Text style={styles.usage}>{item.usage}</Text>
              </View>
            ))}
          </ScrollView>
                  </View>
                  </View>
      </View>

      {/* RIGHT PANEL */}
      <View style={styles.rightPanel}>
        <KitPlaceholder width={160} height={160} />
      </View>

      {/* ✅ MODAL */}
      <Modal transparent visible={showModal} animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            {/* HEADER */}
            <View style={styles.modalHeader}>
              <View>
                <Text style={styles.modalTitle}>Dosage Calculator</Text>
                <Text style={styles.modalSub}>Calculate Safe Dosage</Text>
              </View>

              <TouchableOpacity onPress={() => setShowModal(false)}>
                <MaterialIcons name="close" size={22} color={"black"} />
              </TouchableOpacity>
            </View>

            {/* INPUTS */}
            <View style={styles.modalRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.label}>Medication</Text>
                <TextInput
                  placeholder="Drug name"
                  style={styles.input}
                  placeholderTextColor="#4A5568"
                />
              </View>

              <View style={{ flex: 1 }}>
                <Text style={styles.label}>Weight (kg)</Text>
                <TextInput
                  placeholder="85"
                  style={styles.input}
                  keyboardType="numeric"
                  placeholderTextColor="#4A5568"
                />
              </View>
            </View>

            {/* BUTTON */}
            <TouchableOpacity style={styles.calculateBtn}>
              <Text style={styles.calculateText}>Calculate</Text>
            </TouchableOpacity>

            {/* RESULT */}
            <View style={styles.resultBox}>
              <Text style={styles.resultLabel}>Recommended Dosage</Text>
              <Text style={styles.resultValue}>10 Mg</Text>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const DATA = [
  {
    name: "INJ Atropine ampoule 600 mcg /ml",
    usage: "Slow heart rate / Cardiac arrest",
  },
  { name: "INJ Adrenaline 1:1000 ampoule", usage: "Anaphylaxis" },
  { name: "Epipen OR NEFFY (Out of Stock)", usage: "Anaphylaxis" },
  { name: "INJ Midazolam", usage: "Seizure" },
  {
    name: "INJ Amiodarone Ampoule",
    usage: "Ventricular tachycardia / Fibrillation",
  },
  { name: "Hydrocortisone 250 mg", usage: "Asthma" },
  { name: "Diphenhydramine", usage: "Allergy" },
  { name: "Aspirin 300 mg tablets", usage: "Chest pain / MI" },
  { name: "GTN Spray 400 mcg", usage: "Angina" },
  { name: "Salbutamol inhaler", usage: "Asthma" },
];

const styles = StyleSheet.create({
  root: {
    flex: 1,
    flexDirection: "row",
    backgroundColor: "#F3F4F6",
  },

  leftPanel: {
    flex: 1,
    padding: 16,
  },

  rightPanel: {
    width: 260,
    backgroundColor: "#EAF1FF",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 20,
    margin: 16,
  },

  title: {
    fontSize: 20,
    fontWeight: "700",
    marginBottom: 12,
    color: "#171923",
    fontWeight: 700,
  },

  topRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginBottom: 12,
  },

  tabs: {
    flexDirection: "row",
    backgroundColor: "#E5E7EB",
    borderRadius: 20,
  },

  tabBtn: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },

  tabActive: {
    backgroundColor: "#0A5FFF",
  },

  tabInactive: {
    backgroundColor: "#E5E7EB",
  },

  tabText: {
    fontSize: 12,
    color: "#1F2024",
    paddingHorizontal: 12,
    gap: 8,
    height: 30,
  },

  tabTextActive: {
    color: "#fff",
    fontWeight: "600",
    paddingHorizontal: 12,
    gap: 8,
  },

  searchBox: {
    width: 180,
    marginLeft: "auto",
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#F6F9FF",
    borderRadius: 24,
    paddingHorizontal: 12,
    gap: 8,
  },

  searchInput: {
    flex: 1,
    fontSize: 12,
  },

  calcBtn: {
    flexDirection: "row",
    backgroundColor: "#015DFF",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: "center",
    gap: 6,
  },

  calcText: {
    color: "#fff",
    fontSize: 11,
    fontWeight: "600",
    },
  
  moduleContainer: {
  backgroundColor: "#F6F9FF",
  padding: 12,
  borderRadius: 12,
},

  moduleHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  moduleTitle: {
    fontSize: 13,
    fontWeight: "700",
    color: "#0A5FFF",
  },

  moduleDesc: {
    fontSize: 11,
    color: "#6B7280",
    marginBottom: 10,
  },

  tableContainer: {
    borderWidth: 1,
    borderColor: "#D6E4FF",
    borderRadius: 10,
    overflow: "hidden",
    backgroundColor: "#FFFFFF",
  },

  tableHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    backgroundColor: "#EAF1FF",
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#E5E7EB",
  },

  th: {
    fontSize: 11,
    fontWeight: "600",
    color: "#1F2024",
    width: "48%",
  },

  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#E5E7EB",
    backgroundColor: "#FFFFFF",
  },

  name: {
    fontSize: 11,
    width: "48%",
    color: "#1F2024",
  },

  usage: {
    fontSize: 11,
    width: "48%",
    color: "#4B5563",
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "center",
    alignItems: "center",
  },
  //modal
  modalCard: {
    width: 400,
    backgroundColor: "#F3F4F6",
    borderRadius: 20,
    padding: 20,
  },

  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },

  modalTitle: {
    fontSize: 24,
    fontWeight: "700",
    color: "#171923",
  },

  modalSub: {
    fontSize: 12,
    color: "#1A1A1A",
  },

  modalRow: {
    flexDirection: "row",
    gap: 10,
    marginBottom: 16,
  },

  label: {
    fontSize: 12,
    color: "#718096",
    marginBottom: 6,
  },

  input: {
    backgroundColor: "#E5E7EB",
    borderRadius: 10,
    padding: 10,
    fontSize: 12,
  },

  calculateBtn: {
    backgroundColor: "#0A5FFF",
    padding: 14,
    borderRadius: 12,
    alignItems: "center",
    marginBottom: 16,
  },

  calculateText: {
    color: "#fff",
    fontWeight: "600",
  },

  resultBox: {
    backgroundColor: "#E5E7EB",
    borderRadius: 12,
    padding: 14,
  },

  resultLabel: {
    fontSize: 11,
    color: "#5F6368",
    fontWeight: 700,
  },

  resultValue: {
    fontSize: 24,
    fontWeight: "700",
    color: "#171923",
  },
});
