// screens/AllEventsScreen.js
import React, { useState, useRef } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  TextInput,
  ScrollView,
  Modal,
  TouchableWithoutFeedback,
  Image,
} from "react-native";

import Sidebar from "../components/Sidebar";
import MaterialIcons from "react-native-vector-icons/MaterialIcons";
import MaterialCommunityIcons from "react-native-vector-icons/MaterialCommunityIcons";
//modals import
import RightVitalsPanel from "../components/RightVitalsPanel";
import SpO2Component from "../components/spo2component";
import AssignPhysicianModal from "../components/AssignPhysicianModal";
import ShareModal from "../components/ShareModal";

// ─── SVG IMPORTS ─────────────────────────────────────────────
import CalendarIcon from "../assets/Images/calander.svg";
import FilterIcon from "../assets/Images/filtericon.svg";
import ExportIcon from "../assets/Images/exporticon.svg";
import SearchIcon from "../assets/Images/Search.svg";

// Action button SVGs — update filenames to match exactly what's in your folder
import EyeIcon from "../assets/Images/Eye.svg";
import MedicalIcon from "../assets/Images/vitalplus.svg";
import HeartIcon from "../assets/Images/vitalheart.svg";
import VideoIcon from "../assets/Images/videoicon.svg";

// ─── PNG MENU ICONS ──────────────────────────────────────────
const MENU_ITEMS = [
  {
    label: "View Vital Trends",
    icon: require("../assets/Images/viewvitaltrends.png"),
  },
  { label: "View report", icon: require("../assets/Images/viewreport.png") },
  { label: "Share report", icon: require("../assets/Images/share.png") },
  {
    label: "Close & Archive case",
    icon: require("../assets/Images/closeandarchive.png"),
  },
];

// ─── COLUMN DEFINITIONS ──────────────────────────────────────
const C = {
  checkbox: { width: 36 },
  flight: { flex: 1, minWidth: 0 },
  name: { flex: 1.7, minWidth: 0 },
  mrn: { flex: 1.4, minWidth: 0 },
  status: { flex: 0.9, minWidth: 0 },
  route: { flex: 1.1, minWidth: 0 },
  physician: { flex: 1.3, minWidth: 0 },
  crew: { flex: 1, minWidth: 0 },
  actions: { flex: 1.9, minWidth: 0 }, //1.9
};

// ─── DATA ────────────────────────────────────────────────────
const ROWS = Array.from({ length: 10 }, (_, i) => ({
  id: i,
  flight: "AA1234",
  seat: "A15",
  name: "Lisha Cook",
  age: "45y (F)",
  mrn: "719471345",
  patientId: "NA",
  status: "Critical",
  route: "SYD → LAX",
  physicianStatus: i === 0 ? "assign" : "named",
  physician: "Alex Tobar",
  crew: "Julia R",
}));

// ─── STAT CARD ───────────────────────────────────────────────
const StatCard = ({ icon, value, label }) => (
  <View style={s.statCard}>
    <MaterialCommunityIcons name={icon} size={22} color="#6B7280" />
    <View>
      <Text style={s.statValue}>{value}</Text>
      <Text style={s.statLabel}>{label}</Text>
    </View>
  </View>
);

// ─── SVG ACTION BUTTON ───────────────────────────────────────
const SvgActionBtn = ({ SvgIcon, onPress }) => (
  <TouchableOpacity style={s.actBtn} onPress={onPress}>
    <View pointerEvents="none">
      <SvgIcon width={14} height={14} color="#2563EB" />
    </View>
  </TouchableOpacity>
);

// ─── THREE DOT POPUP MENU ────────────────────────────────────
const ThreeDotMenu = ({ onViewTrends, onShare , onViewReport }) => {
  const [visible, setVisible] = useState(false);
  // const [showVitals, setShowVitals] = useState(false);
  const [menuPos, setMenuPos] = useState({ x: 0, y: 0 });
  const btnRef = useRef(null);

  const openMenu = () => {
    btnRef.current?.measureInWindow((x, y, width, height) => {
      setMenuPos({ x: x - 160 + width + 20, y: y + height + 4 });
      setVisible(true);
    });
  };

  const handlePress = (item) => {
    setVisible(false);

    if (item.label === "View Vital Trends") {
      console.log("VIEW TRENDS CLICKED"); 
      onViewTrends?.(); // 🔥 optional chaining
    }
    if (item.label === "Share report") {
       console.log("share report modal clicked"); 
    onShare?.(); // 🔥 NEW
    }
   if (item.label === "View report") {
  onViewReport?.(); // 👈 ADD THIS
}
  };

  return (
    <>
      <TouchableOpacity ref={btnRef} style={s.actBtn} onPress={openMenu}>
        <MaterialIcons name="more-vert" size={14} color="#2563EB" />
      </TouchableOpacity>

      <Modal visible={visible} transparent animationType="none">
        <TouchableWithoutFeedback onPress={() => setVisible(false)}>
          <View style={s.modalOverlay}>
            <TouchableWithoutFeedback>
              <View
                style={[
                  s.menuCard,
                  {
                    top: menuPos.y,
                    left: menuPos.x,
                    transform: [{ translateX: -90 }],
                  },
                ]}
              >
                {MENU_ITEMS.map((item) => (
                  <TouchableOpacity
                    key={item.label}
                    style={s.menuItem}
                    onPress={() => handlePress(item)}
                  >
                    <Image source={item.icon} style={s.menuIcon} />
                    <Text style={s.menuLabel}>{item.label}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </TouchableWithoutFeedback>
          </View>
        </TouchableWithoutFeedback>
      </Modal>
    </>
  );
};

// ─── TABLE HEADER ────────────────────────────────────────────
const TableHeader = ({ selectAll, onToggleAll }) => (
  <View style={s.headerRow}>
    <TouchableOpacity style={s.checkCell} onPress={onToggleAll}>
      <View style={[s.checkbox, selectAll && s.checkboxOn]}>
        {selectAll && <MaterialIcons name="check" size={10} color="#fff" />}
      </View>
    </TouchableOpacity>

    <Text style={[s.hCell, C.flight]}>{"Flight #\nSeat"}</Text>
    <Text style={[s.hCell, C.name]}>{"Name\nAge (Gender)"}</Text>
    <Text style={[s.hCell, C.mrn]}>{"MRN\n(Patient ID)"}</Text>

    <View style={[s.hSortCell, C.status]}>
      <Text style={s.hTxt}>Status</Text>
      <MaterialIcons name="unfold-more" size={11} color="#9CA3AF" />
    </View>
    <View style={[s.hSortCell, C.route]}>
      <Text style={s.hTxt}>Flight Route</Text>
      <MaterialIcons name="unfold-more" size={11} color="#9CA3AF" />
    </View>
    <View style={[s.hSortCell, C.physician]}>
      <Text style={s.hTxt}>Physician</Text>
      <MaterialIcons name="unfold-more" size={11} color="#9CA3AF" />
    </View>
    <View style={[s.hSortCell, C.crew]}>
      <Text style={s.hTxt}>Crew</Text>
      <MaterialIcons name="unfold-more" size={11} color="#9CA3AF" />
    </View>
    <Text style={[s.hCell, C.actions]}>Actions</Text>
  </View>
);

// ─── DATA ROW ────────────────────────────────────────────────
const TableRow = ({
  row,
  index,
  selected,
  onToggle,
  onOpenVitals,
  onAssignPress,
  onSharePress,
  onNamePress,
  onECGPress, 
}) => (
  <View style={[s.row, index % 2 === 1 && s.rowAlt]}>
    <TouchableOpacity style={s.checkCell} onPress={() => onToggle(row.id)}>
      <View style={[s.checkbox, selected && s.checkboxOn]}>
        {selected && <MaterialIcons name="check" size={10} color="#fff" />}
      </View>
    </TouchableOpacity>

    <Text style={[s.dCell, C.flight]} numberOfLines={2}>
      {row.flight}
      {"\n"}
      <Text style={s.subTxt}>{row.seat}</Text>
    </Text>
    <TouchableOpacity
  style={C.name}
  activeOpacity={0.7}
  onPress={onNamePress}
>
  <Text style={s.dCell} numberOfLines={2}>
    {row.name}
    {"\n"}
    <Text style={s.subTxt}>{row.age}</Text>
  </Text>
</TouchableOpacity>
    <Text style={[s.dCell, C.mrn]} numberOfLines={2}>
      {row.mrn}
      {"\n"}
      <Text style={s.subTxt}>{"ID: " + row.patientId}</Text>
    </Text>
    <Text style={[s.dCell, s.statusTxt, C.status]} numberOfLines={1}>
      {row.status}
    </Text>
    <Text style={[s.dCell, C.route]} numberOfLines={1}>
      {row.route}
    </Text>

   <View style={[s.badgeCell, C.physician]}>
  <TouchableOpacity onPress={onAssignPress}>
    {row.physicianStatus === "assign" ? (
      <View style={s.badgeYellow}>
        <Text style={s.badgeTxt}>Assign</Text>
      </View>
    ) : (
      <View style={s.badgeGreen}>
        <Text style={s.badgeTxt}>{row.physician}</Text>
      </View>
    )}
  </TouchableOpacity>
</View>

    <View style={[s.badgeCell, C.crew]}>
      <View style={s.badgeBlue}>
        <Text style={s.badgeTxt}>{row.crew}</Text>
      </View>
    </View>

    {/* ── ACTION BUTTONS WITH SVG ICONS ── */}
    <View style={[s.actionsCell, C.actions]}>
      <SvgActionBtn SvgIcon={EyeIcon} />
      <SvgActionBtn
        SvgIcon={MedicalIcon}
        onPress={() => onOpenVitals?.(row, false)}
      />
      <SvgActionBtn SvgIcon={HeartIcon} onPress={onECGPress} />
      <SvgActionBtn SvgIcon={VideoIcon} />
      <ThreeDotMenu
        onViewTrends={() => {
          console.log("CALLING OPEN VITALS FROM ROW");
          onOpenVitals(row, true); 
        }}
        onShare={() => onSharePress(row)}
        onViewReport={() =>
    navigation.navigate("CaseOutcomeScreen", { patient: row })
  }
      />
    </View>
  </View>
);

// ─── MAIN SCREEN ─────────────────────────────────────────────
export default function AllEventsScreen({ navigation }) {
  const [selected, setSelected] = useState({});
  const [selectAll, setSelectAll] = useState(false);
  //vital panel
  const [showPanel, setShowPanel] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState(null);
  //vital trends
  const [showTrends, setShowTrends] = useState(false);
  //Modals
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  //Rows
  const [rows, setRows] = useState(ROWS);
const [selectedRowId, setSelectedRowId] = useState(null);

  const patientInfo = {
    name: "John Smith",
    age: "58 M",
    flight: "AA1234",
    route: "SYD → LAX",
  };

  const toggleRow = (id) =>
    setSelected((prev) => ({ ...prev, [id]: !prev[id] }));

  const openAssignModal = (row) => {
  setSelectedRowId(row.id);
  setShowAssignModal(true);
};
const handleAssignDoctor = (doctor) => {
  setRows((prev) =>
    prev.map((row) =>
      row.id === selectedRowId
        ? {
            ...row,
            physician: doctor.name,
            physicianStatus: "named",
          }
        : row
    )
  );
  };
   const onSharePress = (row) => {
    setShowShareModal(true);
  };
  const toggleAll = () => {
    const next = !selectAll;
    setSelectAll(next);
    const map = {};
    ROWS.forEach((r) => (map[r.id] = next));
    setSelected(map);
  };

  // ✅ OPEN PANEL
  const openVitalsPanel = (row, isTrends = false) => {
    console.log("OPEN PANEL", isTrends);

    setSelectedPatient(row);
    setShowPanel(true);
    setShowTrends(isTrends);
  };
  return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="light-content" backgroundColor="black" />

      <View style={s.root}>
        <Sidebar navigation={navigation} activeKey="allEvents" />
        {/* 🔥 WRAPPER FOR MAIN + PANEL */}
        <View style={{ flex: 1, flexDirection: "row" }}>
          <View style={[s.main, { flex: 1 }]}>
            {/* TOP STATS */}
            <View style={s.top}>
              <View style={s.greet}>
                <Text style={s.g1}>Good morning 🌤</Text>
                <Text style={s.g2}>Dr. James Oktar</Text>
                <Text style={s.g3}>MD - Neurology</Text>
              </View>
              <StatCard
                icon="calendar-month-outline"
                value="XX"
                label="Events today"
              />
              <StatCard
                icon="account-outline"
                value="XX/XX"
                label="Patients to see"
              />
              <StatCard
                icon="account-plus-outline"
                value="XX"
                label="Patients to assign"
              />
              <StatCard
                icon="alert-circle-outline"
                value="XX"
                label="Critical Cases"
              />
            </View>

            {/* SEARCH ROW */}
            <View style={s.searchRow}>
              <TouchableOpacity style={s.dateBox}>
                <MaterialIcons name="chevron-left" size={16} color="#6B7280" />
                <CalendarIcon width={14} height={14} />
                <Text style={s.dateText}>Jan 26</Text>
                <MaterialIcons name="chevron-right" size={16} color="#6B7280" />
              </TouchableOpacity>

              <View style={s.searchBox}>
                <SearchIcon width={16} height={16} />
                <TextInput
                  placeholder="Search flight route, patients by name or MRN..."
                  placeholderTextColor="#9CA3AF"
                  style={s.searchInput}
                />
              </View>

              <View style={s.rightBtns}>
                <TouchableOpacity style={s.outlineBtn}>
                  <FilterIcon width={14} height={14} />
                  <Text style={s.btnText}>Filter</Text>
                </TouchableOpacity>
                <TouchableOpacity style={s.outlineBtn}>
                  <ExportIcon width={14} height={14} />
                  <Text style={s.btnText}>Export</Text>
                </TouchableOpacity>
              </View>
            </View>

            {/* TABLE */}
            <View style={s.tableWrapper}>
              <TableHeader selectAll={selectAll} onToggleAll={toggleAll} />
              <ScrollView
                style={{ flex: 1 }}
                contentContainerStyle={{ paddingBottom: 16 }}
                showsVerticalScrollIndicator={false}
              >
                {rows.map((row, index) => (
                  <TableRow
                    key={row.id}
                    row={row}
                    index={index}
                    selected={!!selected[row.id]}
                    onToggle={toggleRow}
                    onViewTrends={() => onOpenVitals?.(row, true)}
                    onOpenVitals={openVitalsPanel}
                    onAssignPress={() => openAssignModal(row)}
                    onSharePress={onSharePress}
                    onNamePress={() =>
    navigation.navigate("CaseDetail", { patient: row })
  }
                    onECGPress={() => navigation.navigate("ECGScreen")} 
                    
                  />
                ))}
              </ScrollView>
            </View>

            {/* ✅ RIGHT PANEL */}
            {showPanel && (
              <View
                style={{
                  position: "absolute",
                  right: 0,
                  top: 0,
                  bottom: 0,
                  width: 300,
                  backgroundColor: "#1B1C3A",
                  zIndex: 1000,
                  elevation: 10,
                  padding: 16,
                }}
              >
                {showTrends ? (
                  // 🔥 SHOW VITAL TRENDS UI

                  <SpO2Component
                    patientInfo={patientInfo}
                    onClose={() => setShowPanel(false)}
                  />
                ) : (
                  // 🔥 NORMAL VITAL PANEL
                  <RightVitalsPanel
                    showHeader={true}
                    showTrendsButton={false}
                    patientInfo={{
                      name: selectedPatient?.name,
                      age: selectedPatient?.age,
                      gender: "M",
                      flight: selectedPatient?.flight,
                      route: selectedPatient?.route,
                    }}
                    onClose={() => {
                      setShowPanel(false);
                      setShowTrends(false); // ✅ reset when closing
                    }}
                  />
                )}
              </View>
            )}
          </View>
        </View>
        <AssignPhysicianModal
  visible={showAssignModal}
  onClose={() => setShowAssignModal(false)}
  onAssign={handleAssignDoctor}
        />
        
        <ShareModal
  visible={showShareModal}
  onClose={() => setShowShareModal(false)}
/>
      </View>
    </SafeAreaView>
  );
}

// ─── STYLES ──────────────────────────────────────────────────
const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F3F4F6" },
  root: { flex: 1, flexDirection: "row", backgroundColor: "#F3F4F6" },
  main: {
    flex: 1,
    minWidth: 0,
    flexDirection: "column",
    backgroundColor: "#F3F4F6",
    minWidth: 0,
  },

  // ── TOP ──
  top: { flexDirection: "row", gap: 10, padding: 10, alignItems: "stretch" },
  greet: {
    backgroundColor: "#1565C0",
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
    justifyContent: "center",
    minWidth: 150,
  },
  g1: { color: "#fff", fontSize: 11, fontWeight: "500" },
  g2: { color: "#fff", fontSize: 14, fontWeight: "700", marginTop: 2 },
  g3: { color: "#BFDBFE", fontSize: 11, marginTop: 1 },
  statCard: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  statValue: { fontWeight: "700", fontSize: 15, color: "#111827" },
  statLabel: { fontSize: 11, color: "#6B7280", marginTop: 1 },

  // ── SEARCH ──
  searchRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingBottom: 8,
  },
  dateBox: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderRadius: 10,
    paddingHorizontal: 8,
    paddingVertical: 8,
    gap: 2,
  },
  dateText: { fontSize: 12, color: "#111827", fontWeight: "500" },
  searchBox: {
    flex: 1,
    minWidth: 0,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderRadius: 10,
    paddingHorizontal: 12,
    height: 38,
    gap: 8,
    marginHorizontal: 10,
  },
  searchInput: {
    flex: 1,
    minWidth: 0,
    fontSize: 12,
    color: "#111827",
    padding: 0,
  },
  rightBtns: { flexDirection: "row", gap: 8 },
  outlineBtn: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#2563EB",
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 8,
    gap: 6,
    backgroundColor: "#fff",
  },
  btnText: { color: "#2563EB", fontSize: 12, fontWeight: "600" },
  rightPanel: {
    width: 300,
    backgroundColor: "#0F172A",
    borderLeftWidth: 1,
    borderColor: "#1F2937",
    paddingHorizontal: 10,
    paddingTop: 10,
  },
  // ── TABLE ──
  tableWrapper: {
    flex: 1,
    marginHorizontal: 10,
    marginBottom: 10,
    backgroundColor: "#fff",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    overflow: "hidden",
  },
  headerRow: {
    flexDirection: "row",
    backgroundColor: "#F9FAFB",
    borderBottomWidth: 1,
    borderColor: "#E5E7EB",
    paddingVertical: 10,
    alignItems: "center",
  },
  hCell: {
    paddingHorizontal: 8,
    fontWeight: "700",
    color: "#374151",
    fontSize: 11,
    lineHeight: 16,
  },
  hSortCell: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 8,
    gap: 2,
  },
  hTxt: { fontWeight: "700", color: "#374151", fontSize: 11 },

  row: {
    flexDirection: "row",
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderColor: "#F3F4F6",
    alignItems: "center",
    backgroundColor: "#fff",
  },
  rowAlt: { backgroundColor: "#FAFAFA" },
  dCell: {
    paddingHorizontal: 8,
    fontSize: 11,
    color: "#111827",
    lineHeight: 17,
  },
  subTxt: { fontSize: 10, color: "#6B7280" },
  statusTxt: { color: "#DC2626", fontWeight: "600" },
  badgeCell: { paddingHorizontal: 8, justifyContent: "center" },
  actionsCell: {
    paddingHorizontal: 4,
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },

  // ── CHECKBOX ──
  checkCell: { width: 36, alignItems: "center", justifyContent: "center" },
  checkbox: {
    width: 16,
    height: 16,
    borderWidth: 1.5,
    borderColor: "#D1D5DB",
    borderRadius: 3,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  checkboxOn: { backgroundColor: "#2563EB", borderColor: "#2563EB" },

  // ── BADGES ──
  badgeGreen: {
    backgroundColor: "#D1FAE5",
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 6,
    alignSelf: "flex-start",
  },
  badgeBlue: {
    backgroundColor: "#DBEAFE",
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 6,
    alignSelf: "flex-start",
  },
  badgeYellow: {
    backgroundColor: "#FEF3C7",
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 6,
    alignSelf: "flex-start",
  },
  badgeTxt: { fontSize: 10, color: "#111827", fontWeight: "500" },

  // ── ACTION BUTTONS ──
  actBtn: {
    borderWidth: 1,
    borderColor: "#E5E7EB",
    padding: 6,
    borderRadius: 6,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },

  // ── THREE DOT POPUP ──
  modalOverlay: { flex: 1, backgroundColor: "transparent" },
  menuCard: {
    position: "absolute",
    backgroundColor: "#fff",
    borderRadius: 12,
    paddingVertical: 6,
    minWidth: 210,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 12,
    elevation: 8,
    borderWidth: 1,
    borderColor: "#F3F4F6",
  },
  menuItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 11,
    paddingHorizontal: 16,
    gap: 12,
    borderRadius: 8,
    marginHorizontal: 4,
  },
  menuItemActive: { backgroundColor: "#EBF2FF" },
  menuIcon: { width: 20, height: 20, tintColor: "#2563EB" },
  menuLabel: { fontSize: 13, color: "#374151", fontWeight: "500" },
  menuLabelActive: { color: "#1D4ED8", fontWeight: "600" },
});
