import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  TextInput,
  FlatList,
} from "react-native";

import MaterialIcons from "react-native-vector-icons/MaterialIcons";

const DOCTORS = [
  { id: 1, name: "Dr. Ramesh Madhavan", available: "Available • 12 events today" },
  { id: 2, name: "Dr. Thomas Shelby", available: "Available" },
  { id: 3, name: "Dr. Caroline Jensen", available: "Available" },
  { id: 4, name: "Dr. Aaron Ross", available: "Available" },
];

const AssignPhysicianModal = ({ visible, onClose, onAssign  }) => {
  const [selectedId, setSelectedId] = useState(1);

  if (!visible) return null;

  return (
    <Modal transparent animationType="fade">
      <View style={styles.overlay}>

        <View style={styles.card}>

          {/* HEADER */}
          <View style={styles.header}>
            <Text style={styles.title}>Assign to Provider</Text>

            <TouchableOpacity onPress={onClose}>
              <MaterialIcons name="close" size={20} color="#2563EB" />
            </TouchableOpacity>
          </View>

          {/* SEARCH */}
          <View style={styles.searchBox}>
            <MaterialIcons name="search" size={18} color="#006FFD" />
            <TextInput
              placeholder="Search by name or specialty"
                          style={styles.input}
                          placeholderTextColor="#8F9098"   
            />
          </View>

          {/* LIST */}
          <FlatList
            data={DOCTORS}
            keyExtractor={(item) => item.id.toString()}
            contentContainerStyle={{ gap: 10 }}
            renderItem={({ item }) => {
              const selected = item.id === selectedId;

              return (
                <TouchableOpacity
                  style={[
                    styles.doctorCard,
                    selected && styles.selectedCard,
                  ]}
                  onPress={() => setSelectedId(item.id)}
                >
                  <View>
                    <Text style={styles.docName}>{item.name}</Text>
                    <Text style={styles.available}>{item.available}</Text>
                  </View>

                  {selected && (
                    <MaterialIcons
                      name="check"
                      size={18}
                      color="#2563EB"
                    />
                  )}
                </TouchableOpacity>
              );
            }}
          />

          {/* BUTTON */}
         <TouchableOpacity
  style={styles.assignBtn}
  onPress={() => {
    const selectedDoctor = DOCTORS.find(d => d.id === selectedId);
    onAssign(selectedDoctor);   // 🔥 send to parent
    onClose();
  }}
>
  <Text style={styles.assignText}>Assign</Text>
</TouchableOpacity>

        </View>
      </View>
    </Modal>
  );
};

export default AssignPhysicianModal;


// ───────── STYLES ─────────
const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.3)",
    justifyContent: "center",
    alignItems: "center",
  },

  card: {
    width: 400,
    maxHeight: "85%",
    backgroundColor: "#fff",
    borderRadius: 20,
    padding: 16,
  },

  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },

  title: {
    fontSize: 14,
      fontWeight: "700",
        color:'#1F2024'
  },

  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#F3F4F6",
    borderRadius: 12,
    paddingHorizontal: 10,
    height: 40,
    marginBottom: 12,
    gap: 6,
  },

  input: {
    flex: 1,
      fontSize: 11,
    
   
  },

  doctorCard: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#E5E7EB",
  },

  selectedCard: {
    backgroundColor: "#EAF2FF",
    borderColor: "#2563EB",
  },

  docName: {
    fontSize: 13,
      fontWeight: "400",
    color:'#1F2024'
  },

  available: {
    fontSize: 11,
    color: "#16A34A",
    marginTop: 2,
  },

  assignBtn: {
    marginTop: 14,
    backgroundColor: "#1D4ED8",
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: "center",
  },

  assignText: {
    color: "#fff",
    fontWeight: "600",
  },
});