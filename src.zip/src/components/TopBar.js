// components/TopBar.js
import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity,
  StyleSheet, Platform, StatusBar,
  useWindowDimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation } from '@react-navigation/native';
import NotificationPanel  from '../screens/NotificationPanel';



// ─── Helper ───────────────────────────────────────────────────────────────────
function useTopInset() {
  try {
    const insets = useSafeAreaInsets();
    return insets.top;
  } catch {
    return Platform.OS === 'android' ? (StatusBar.currentHeight ?? 24) : 44;
  }
}




//DetailedTopBar  →  All other screens
// //    Left : ✅ Device Connected / ❌ Not Connected · 🔄 Last Synced
// //    Right: Call Doctor · Chat · Notification
// // ─────────────────────────────────────────────────────────────────────────────

export function DetailedTopBar({
  navigation,
  showNotification = true,
  onNotification,
  notifications,
  deviceConnected = true,
  syncTime = 'Today 12:00 PM',

  // ✅ NEW (but optional — won’t break anything)
  patientName = 'John Smith, 58 M',
  flight = 'Flight AA1234, SYD → LAX',

}) {
  const topInset = useTopInset();
  const navigationHook = useNavigation();
  const [panelVisible, setPanelVisible] = useState(false);

  const handleNotification = () => {
    if (onNotification) onNotification();
    else setPanelVisible(true);
  };

  return (
    <>
      <View style={[styles.container, { paddingTop: topInset + 6 }]}>

        {/* ───────── TOP STRIP ───────── */}
        <View style={styles.topStrip}>

          <View style={[styles.deviceBadge, !deviceConnected && styles.deviceBadgeOff]}>
            <MaterialIcons
              name={deviceConnected ? 'check-circle' : 'cancel'}
              size={14}
              color={deviceConnected ? '#43A047' : '#FB8C00'}
            />
            <Text style={[styles.deviceText, !deviceConnected && styles.deviceTextOff]}>
              {deviceConnected ? 'Device Connected' : 'Not Connected'}
            </Text>
          </View>

          <View style={styles.syncBadge}>
            <MaterialCommunityIcons name="sync" size={13} color="#666" />
            <Text style={styles.syncText}>Last synced {syncTime}</Text>
          </View>

        </View>

        {/* ───────── MAIN ROW ───────── */}
        <View style={styles.mainRow}>

          {/* LEFT: Patient Info */}
          <View>
            <Text style={styles.patientName}>{patientName}</Text>
            <Text style={styles.flightText}>{flight}</Text>
          </View>

          {/* RIGHT: Actions */}
          <View style={styles.actions}>

            {/* JOIN NOW */}
            <TouchableOpacity
              style={styles.joinBtn}
              onPress={() =>
                navigationHook.navigate('Meeting', {
                  roomId: 'test123',
                  userName: 'Doctor',
                })
              }
            >
              <MaterialIcons name="videocam" size={16} color="#fff" />
              <Text style={styles.joinText}>Join Now</Text>
            </TouchableOpacity>

            {/* NOTIFICATION */}
            {showNotification && (
              <TouchableOpacity style={styles.bellBtn} onPress={handleNotification}>
                <MaterialIcons name="notifications-none" size={18} color="#fff" />
              </TouchableOpacity>
            )}

          </View>
        </View>
      </View>

      <NotificationPanel
        visible={panelVisible}
        onClose={() => setPanelVisible(false)}
        notifications={notifications}
      />
    </>
  );
}
// ─────────────────────────────────────────────────────────────────────────────
// Styles (NO CHANGE)
// ─────────────────────────────────────────────────────────────────────────────
// // ─── Styles ───────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  simpleBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    paddingHorizontal: 10,
    paddingBottom: 8,
   
    gap: 8,
  },
  rightActions: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 8,
  },
  detailedBar: {
    backgroundColor: '#fff',
    paddingHorizontal: 12,
    paddingBottom: 8,
   
  },
  detailedRowSingle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  leftGroup:  { flexDirection: 'row', alignItems: 'center', gap: 10 },
  rightGroup: { flexDirection: 'row', alignItems: 'center', gap: 6  },

  newEventBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1565C0',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 7,
    marginRight: 8,
  },
  newEventBtnSmall: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1565C0',
    borderRadius: 7,
    paddingHorizontal: 12,
    paddingVertical: 7,
  },
  newEventBtnText: { color: '#fff', fontSize: 12, fontWeight: '700' },

  outlineBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#015DFF',
    borderRadius: 7,
    paddingHorizontal: 9,
    paddingVertical: 5,
    backgroundColor: '#fff',
    gap: 5,
  },
  outlineBtnText: { fontSize: 11, color: '#015DFF', fontWeight: '600' },

  micBtn: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#015DFF',
    borderRadius: 7,
    width: 32,
    height: 32,
    backgroundColor: '#fff',
  },

  iconBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#015DFF',
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },

  connectDeviceBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#015DFF',
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: '#90CAF9',
    gap: 6,
  },
  connectDeviceText: { color: '#fff', fontSize: 11, fontWeight: '600' },

  deviceBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#E8F5E9',
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: '#A5D6A7',
    gap: 5,
  },
deviceBadge: {
  flexDirection: 'row',
  alignItems: 'center',
  borderRadius: 27,        
  paddingTop: 6,           
  paddingBottom: 6,
  paddingLeft: 16,
  paddingRight: 16,
  gap: 6,                 
  backgroundColor: '#E8F5E9',
  borderWidth: 1,
  borderColor: '#A5D6A7',
},
  deviceText:     { color: '#2E7D32', fontSize: 11, fontWeight: '600' },
  deviceTextOff:  { color: '#E65100' },

  syncBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    paddingHorizontal: 10,
    paddingVertical: 4,
    gap: 6,
  },
    syncText: { fontSize: 11, color: '#666', fontWeight: '500' },
  container: {
  backgroundColor: '#fff',
  paddingHorizontal: 14,
      paddingBottom: 10,
  paddingTop: 6,
},

topStrip: {
flexDirection: 'row',
  alignItems: 'center',
  gap: 10,
  marginBottom: 8,
  marginTop: 21,   
},

mainRow: {
  flexDirection: 'row',
  justifyContent: 'space-between',
  alignItems: 'center',
},

patientName: {
  fontSize: 16,
  fontWeight: '700',
  color: '#1F2024',
},

flightText: {
  fontSize: 11,
  color: '#6B7280',
  marginTop: 2,
},

actions: {
  flexDirection: 'row',
  alignItems: 'center',
  gap: 8,
},

joinBtn: {
  flexDirection: 'row',
  alignItems: 'center',
  backgroundColor: '#015DFF',
  borderRadius: 10,
  paddingHorizontal: 12,
  paddingVertical: 8,
  gap: 6,
},

joinText: {
  color: '#fff',
  fontSize: 12,
  fontWeight: '600',
},

bellBtn: {
  width: 38,
  height: 38,
  borderRadius: 10,
  backgroundColor: '#015DFF',
  alignItems: 'center',
  justifyContent: 'center',
},
});