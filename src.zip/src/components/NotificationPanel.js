import React, { useState } from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";

// ✅ Your SVG
import ExclaimIcon from "../assets/Images/exclaimation.svg";

const NotificationPanel = ({ visible, onClose }) => {
  const [alerts, setAlerts] = useState([
    { id: 1, title: "Alert Headline", desc: "Description. Lorem ipsum dolor sit amet." },
    { id: 2, title: "Alert Headline", desc: "Description. Lorem ipsum dolor sit amet." },
    { id: 3, title: "Alert Headline", desc: "Description. Lorem ipsum dolor sit amet." },
  ]);

  if (!visible) return null;

  const removeAlert = (id) => {
    setAlerts((prev) => prev.filter((item) => item.id !== id));
  };

  return (
    <View style={styles.overlay}>

      <View style={styles.panel}>

        {/* HEADER */}
        <View style={styles.header}>
          <Text style={styles.title}>Notification</Text>

          <TouchableOpacity onPress={onClose}>
            <Text style={styles.close}>✕</Text>
          </TouchableOpacity>
              </View>
              
               {/* TODAY BADGE */}
        <View style={styles.todayBadge}>
          <Text style={styles.todayText}>TODAY</Text>
        </View>

        {/* ALERT LIST */}
        <View style={{ gap: 12 }}>
          {alerts.map((item) => (
            <View key={item.id} style={styles.alertCard}>

              {/* LEFT ICON */}
              <View style={styles.iconWrapper}>
                <ExclaimIcon width={14} height={14} fill="#fff" />
              </View>

              {/* TEXT */}
              <View style={{ flex: 1 }}>
                <Text style={styles.alertTitle}>{item.title}</Text>
                <Text style={styles.alertDesc}>{item.desc}</Text>
              </View>

              {/* RIGHT CLOSE */}
              <TouchableOpacity onPress={() => removeAlert(item.id)}>
                <Text style={styles.cardClose}>✕</Text>
              </TouchableOpacity>

            </View>
          ))}
              </View>
              
                        {/* TODAY BADGE */}
        <View style={styles.todayBadge}>
          <Text style={styles.todayText}>12 March 2026</Text>
        </View>

        {/* ALERT LIST */}
        <View style={{ gap: 12 }}>
          {alerts.map((item) => (
            <View key={item.id} style={styles.alertCard}>

              {/* LEFT ICON */}
              <View style={styles.iconWrapper}>
                <ExclaimIcon width={14} height={14} fill="#fff" />
              </View>

              {/* TEXT */}
              <View style={{ flex: 1 }}>
                <Text style={styles.alertTitle}>{item.title}</Text>
                <Text style={styles.alertDesc}>{item.desc}</Text>
              </View>

              {/* RIGHT CLOSE */}
              <TouchableOpacity onPress={() => removeAlert(item.id)}>
                <Text style={styles.cardClose}>✕</Text>
              </TouchableOpacity>

            </View>
          ))}
        </View>

      </View>
    </View>
  );
};

export default NotificationPanel;


// ─────────────────────────────────────────────
// STYLES
// ─────────────────────────────────────────────
const styles = StyleSheet.create({

  overlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },

  panel: {
    position: "absolute",
    right: 0,
    top: 0,
    bottom: 0,
    width: 320,
    backgroundColor: "#fff",
    padding: 16,
    borderLeftWidth: 1,
    borderLeftColor: "#E5E7EB",
  },

  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },

  title: {
    fontSize: 16,
    fontWeight: "700",
    color: "#111",
  },

  close: {
    fontSize: 18,
    color: "#111",
  },

  // ALERT CARD
  alertCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#F8D7DA",
    borderRadius: 14,
    padding: 12,
    gap: 10,
  },

  // RED CIRCLE
  iconWrapper: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: "#EF4444",
    alignItems: "center",
    justifyContent: "center",
  },
  todayBadge: {
    alignSelf: "flex-start",
    backgroundColor: "#EAF2FF",
    paddingTop: 6,
    paddingBottom: 6,
    paddingLeft: 8,
    paddingRight: 8,
    borderRadius: 12,
      marginTop: 10,
      marginBottom:10
    
    },
    todayText: {
    fontSize: 10,
    fontWeight: "600",
    color: "#3C3C4399",
  },
  alertTitle: {
    fontSize: 13,
    fontWeight: "700",
    color: "#111",
    marginBottom: 2,
  },

  alertDesc: {
    fontSize: 11,
    color: "#4B5563",
  },

  cardClose: {
    fontSize: 14,
    color: "#6B7280",
    paddingLeft: 6,
  },

});