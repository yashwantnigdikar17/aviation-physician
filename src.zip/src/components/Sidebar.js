// components/Sidebar.js
import React, { useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet, Image } from "react-native";
import MaterialIcons from "react-native-vector-icons/MaterialIcons";
import TiaAIChat from "./TiaAIChat";
import NotificationPanel from "./NotificationPanel";
const NAV_ITEMS = [
  {
    key: "allEvents",
    label: "All Events",
    icon: "event-note",
    screen: "EventsScreenTable",
  },
  // {
  //   key: "medicines",
  //   label: "Medicines",
  //   icon: "medical-services",
  //   screen: "CaseDetail",
  // },
  { key: "searchKit", label: "Search Kit", icon: "link", screen: "SearchKit" },

  { key: "tiaAI", label: "Tia AI", icon: "auto-awesome", screen: "TiaAI" },

  { key: "faqs", label: "FAQs", icon: "help-outline", screen: "FAQs" },
];

const Sidebar = ({ activeKey, navigation }) => {
  const [showTiaAI, setShowTiaAI] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  return (
    <>
      {/* ✅ SIDEBAR */}
      <View style={styles.sidebar}>
        {/* LOGO */}
        <View style={styles.logoArea}>
          <Image
            source={require("../assets/Images/logo.png")}
            style={styles.logoImage}
            resizeMode="contain"
          />
          <Text style={styles.logoText}>TiaTELE</Text>
        </View>

        {/* 🔔 NOTIFICATION */}
        <TouchableOpacity
  style={styles.notificationBtn}
  onPress={() => setShowNotifications(true)}
>
  <MaterialIcons name="notifications-none" size={20} color="grey" />
</TouchableOpacity>

        {/* NAV ITEMS */}
        <View style={styles.navList}>
          {NAV_ITEMS.map((item) => {
            const isActive = item.key === activeKey;

            return (
              <TouchableOpacity
                key={item.key}
                style={[styles.navItem, isActive && styles.navItemActive]}
                activeOpacity={0.75}
                onPress={() => {
                  if (item.screen === "CaseDetail") {
                    navigation.navigate("CaseDetail");
                  } else if (item.screen === "EventsScreenTable") {
                    navigation.navigate("EventsScreenTable");
                  } else if (item.screen === "SearchKit") {
                    navigation.navigate("SearchKit");
                  } else if (item.screen === "TiaAI") {
                    setShowTiaAI(true); // ✅ open chatbot
                  } else {
                    alert(`${item.label} screen coming soon`);
                  }
                }}
              >
                <MaterialIcons
                  name={item.icon}
                  size={18}
                  color={isActive ? "#1565C0" : "#9AA5B4"}
                />

                <Text
                  style={[styles.navLabel, isActive && styles.navLabelActive]}
                >
                  {item.label}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>

        {/* LOGOUT */}
        <View style={styles.bottomSection}>
          <TouchableOpacity
            style={styles.logoutBtn}
            onPress={() =>
              navigation.reset({
                index: 0,
                routes: [{ name: "Login" }],
              })
            }
          >
            <MaterialIcons name="logout" size={20} color="#d32f2f" />
            <Text style={styles.logoutText}>Logout</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* ✅ CHATBOT (OUTSIDE SIDEBAR — FIXED) */}
      <View style={styles.chatOverlay} pointerEvents="box-none">
        <TiaAIChat visible={showTiaAI} onClose={() => setShowTiaAI(false)} />
         <NotificationPanel
    visible={showNotifications}
    onClose={() => setShowNotifications(false)}
  />
      </View>
    </>
  );
};

export default Sidebar;

const styles = StyleSheet.create({
  sidebar: {
    width: 80,
    backgroundColor: "#fff",
    borderRightWidth: 1,
    borderRightColor: "#EEF0F4",
    alignItems: "center",
    paddingTop: 12,
  },

  logoArea: {
    alignItems: "center",
    marginBottom: 12,
  },

  logoImage: {
    width: 90,
    height: 70,
  },

  logoText: {
    fontSize: 12,
    fontWeight: "800",
    color: "#1565C0",
    letterSpacing: 0.5,
  },

  notificationBtn: {
    marginBottom: 10,
    padding: 6,
    borderRadius: 10,
  },

  navList: {
    width: "100%",
    alignItems: "center",
    gap: 4,
  },

  navItem: {
    width: "100%",
    alignItems: "center",
    paddingVertical: 10,
    paddingHorizontal: 4,
    gap: 4,
  },

  navItemActive: {
    backgroundColor: "#EBF2FF",
    borderRightWidth: 3,
    borderRightColor: "#1565C0",
  },

  navLabel: {
    fontSize: 8,
    color: "#9AA5B4",
    fontWeight: "500",
    textAlign: "center",
  },

  navLabelActive: {
    color: "#1565C0",
    fontWeight: "700",
  },

  bottomSection: {
    marginTop: "auto",
    marginBottom: 20,
    alignItems: "center",
  },

  logoutBtn: {
    alignItems: "center",
    paddingVertical: 10,
    gap: 4,
  },

  logoutText: {
    fontSize: 10,
    color: "#d32f2f",
    fontWeight: "600",
  },

  chatOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 999,
  },
});
