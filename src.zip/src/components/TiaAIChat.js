// components/TiaAIChat.js
import React from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Image,
} from "react-native";
import MaterialIcons from "react-native-vector-icons/MaterialIcons";

export default function TiaAIChat({ visible, onClose, onMinimize }) {
  if (!visible) return null;

  return (
    <View style={styles.overlay}>
      <View style={styles.container}>

        {/* HEADER */}
        <View style={styles.header}>

          {/* ✅ HEADER PNG */}
          <Image
            source={require("../assets/Images/headerimg.png")}
            style={styles.headerImage}
            resizeMode="cover"
          />

          {/* CONTENT */}
          <View style={styles.headerContent}>

            {/* ACTIONS */}
            <View style={styles.headerActions}>
              <TouchableOpacity onPress={onMinimize}>
                <MaterialIcons name="remove" size={22} color="#fff" />
              </TouchableOpacity>

              <TouchableOpacity onPress={onClose}>
                <MaterialIcons name="close" size={22} color="#fff" />
              </TouchableOpacity>
            </View>

            {/* ✅ PROFILE IMAGE (PNG) */}
            <Image
              source={require("../assets/Images/profileimg.png")}
              style={styles.avatar}
              resizeMode="contain"
            />

            <Text style={styles.title}>Hello I’m Tia</Text>
            <Text style={styles.subtitle}>
              How may I help you today?
            </Text>
          </View>
        </View>

        {/* BODY */}
        <View style={styles.body}>
          <View style={styles.messageBox}>
            <Text style={styles.messageText}>
              I’m here to answer any questions you may have..
            </Text>
          </View>
        </View>

        {/* INPUT */}
        <View style={styles.inputBar}>
          <MaterialIcons name="menu" size={20} color="#0A5FFF" />

          <TextInput
            placeholder="Ask me anything or use the mic"
            placeholderTextColor="#6B7280"
            style={styles.input}
          />

          <MaterialIcons name="mic" size={20} color="#0A5FFF" />
          <MaterialIcons name="send" size={20} color="#0A5FFF" />
        </View>

      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  overlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "rgba(0,0,0,0.3)",
  },

  container: {
    position: "absolute",
    left: 100,
    top: 50,
    width: 420,
    height: 630,
    backgroundColor: "#F3F4F6",
    borderRadius: 20,
    overflow: "hidden",

    elevation: 10,
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
  },

  header: {
    height: 160,
    position: "relative",
    overflow: "hidden",
  },

  headerImage: {
    ...StyleSheet.absoluteFillObject,
    width: "100%",
    height: "100%",
  },

  headerContent: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "center",
    alignItems: "center",
  },

  headerActions: {
    position: "absolute",
    right: 12,
    top: 10,
    flexDirection: "row",
    gap: 10,
  },

  /* ✅ NEW AVATAR STYLE */
  avatar: {
    width: 50,
    height: 50,
    marginBottom: 8,
  },

  title: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "700",
  },

  subtitle: {
    color: "#E5E7EB",
    fontSize: 12,
  },

  body: {
    flex: 1,
    padding: 16,
  },

  messageBox: {
    backgroundColor: "#EAF1FF",
    borderRadius: 14,
    padding: 12,
    maxWidth: "80%",
  },

  messageText: {
    fontSize: 12,
    color: "#1F2024",
  },

  inputBar: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#EAF1FF",
    padding: 10,
    gap: 10,
  },

  input: {
    flex: 1,
    backgroundColor: "#fff",
    borderRadius: 20,
    paddingHorizontal: 12,
    height: 36,
    fontSize:10
  },
});