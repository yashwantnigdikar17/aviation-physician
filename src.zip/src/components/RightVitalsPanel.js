import React from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ScrollView,
} from 'react-native';

// SVG IMPORTS
import Heart from '../assets/Images/Heart.svg';
import BloodPressure from '../assets/Images/BloodPressure.svg';
import Oxygen from '../assets/Images/Oxygen.svg';
import RespiratoryRate from '../assets/Images/RespiratoryRate.svg';
import Temperature from '../assets/Images/Temperature.svg';
import Eye from '../assets/Images/Eye.svg';
import Sweating from '../assets/Images/Sweating.svg';
import ECG from '../assets/Images/ECG.svg';
import Pain from '../assets/Images/Pain.svg';
import Glucose from '../assets/Images/Glucose.svg';
import AVPU from '../assets/Images/AVPU.svg';
import Trend from '../assets/Images/Trend.svg';


// ─────────────────────────────────────────────
// VITALS
// ─────────────────────────────────────────────
const VITALS = [
  { label: 'Heart Rate', value: '88', unit: 'bpm', warn: false, warningType: null, showGraph: false, icon: Heart },
  { label: 'Blood Pressure', value: '135/85', unit: 'mmHg', warn: true, warningType: 'red', showGraph: false, icon: BloodPressure },
  { label: 'Oxygen', value: '95', unit: '%', warn: false, warningType: null, showGraph: false, icon: Oxygen },
  { label: 'Respiratory Rate', value: '20', unit: '/min', warn: false, warningType: null, showGraph: false, icon: RespiratoryRate },
  { label: 'Temperature', value: '36.8', unit: '°C', warn: false, warningType: null, showGraph: false, icon: Temperature },
  { label: 'Skin Color', value: 'Normal', unit: '', warn: false, warningType: null, showGraph: false, icon: Eye },
  { label: 'Sweating', value: 'Mild', unit: '', warn: false, warningType: null, showGraph: false, icon: Sweating },
  { label: 'ECG', value: 'Sinus', unit: '', warn: false, warningType: null, showGraph: true, icon: ECG },
  { label: 'Pain Score', value: '6/10', unit: '', warn: true, warningType: 'red', showGraph: false, icon: Pain },
  { label: 'Blood Glucose', value: '100', unit: 'mg/dl', warn: false, warningType: null, showGraph: false, icon: Glucose },
  { label: 'AVPU Score', value: '15', unit: '', warn: false, warningType: null, showGraph: false, icon: AVPU },
];


// ─────────────────────────────────────────────
// ECG GRAPH
// ─────────────────────────────────────────────
const EcgLine = () => (
  <View style={ecgStyles.wrapper}>
    <View style={ecgStyles.baseline} />
    <View style={[ecgStyles.spike, { left: '20%', height: 6 }]} />
    <View style={[ecgStyles.spike, { left: '40%', height: 20 }]} />
    <View style={[ecgStyles.spike, { left: '55%', height: 7 }]} />
    <View style={[ecgStyles.spike, { left: '70%', height: 5 }]} />
  </View>
);

const ecgStyles = StyleSheet.create({
  wrapper: {
    width: 40,
    height: 22,
    justifyContent: 'center',
    overflow: 'hidden',
  },
  baseline: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 10,
    height: 1.5,
    backgroundColor: '#E81314',
  },
  spike: {
    position: 'absolute',
    width: 1.5,
    backgroundColor: '#E81314',
    bottom: 2,
  },
});


// ─────────────────────────────────────────────
// VITAL CARD
// ─────────────────────────────────────────────
const VitalCard = ({
  label, value, unit, warn, warningType, showGraph, icon: Icon,
}) => {
  const isRed = warn && warningType === 'red';
  const isOrange = warn && warningType === 'orange';

  const iconColor = isRed ? '#E81314' : isOrange ? '#FC9432' : '#C5D3E0';

  return (
    <View
      style={[
        styles.card,
        isRed && styles.cardRed,
        isOrange && styles.cardOrange,
      ]}
    >
      <View
        style={[
          styles.accentBar,
          isRed && styles.accentRed,
          isOrange && styles.accentOrange,
        ]}
      />

      <View style={styles.cardContent}>
        <Text style={styles.cardLabel}>{label}</Text>
        <Text
          style={[
            styles.cardValue,
            isRed && styles.textRed,
            isOrange && styles.textOrange,
          ]}
        >
          {value}
          {unit ? <Text style={styles.cardUnit}> {unit}</Text> : null}
        </Text>
      </View>

      {showGraph ? (
        <EcgLine />
      ) : (
        <Icon width={16} height={16} fill={iconColor} />
      )}
    </View>
  );
};


// ─────────────────────────────────────────────
// PANEL
// ─────────────────────────────────────────────
const RightVitalsPanel = ({
  onShowTrends,
  onECGPress,
  showTrendsButton = true, 
  showHeader = false,
  patientInfo = {},
  onClose,
}) => (
  <View style={styles.inner}>

    {/* CONDITIONAL HEADER */}
    {showHeader && (
      <View style={styles.header}>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>
            {patientInfo.name}, {patientInfo.age} {patientInfo.gender}
          </Text>
          <Text style={styles.headerSub}>
            Flight {patientInfo.flight} ({patientInfo.route})
          </Text>
        </View>

        <TouchableOpacity onPress={onClose}>
          <Text style={styles.closeBtn}>✕</Text>
        </TouchableOpacity>
      </View>
    )}

    {/* Show Trends */}
     {showTrendsButton && (
      <TouchableOpacity
        style={styles.showTrendsBtn}
        onPress={onShowTrends}
        activeOpacity={0.8}
      >
        <Trend width={18} height={18} fill="#D2D6DB" />
        <Text style={styles.showTrendsText}>Show Vital trends</Text>
      </TouchableOpacity>
    )}

    <ScrollView
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{ gap: 12 }}
    >
      {VITALS.map((v, i) => {
        if (v.label === 'ECG') {
          return (
            <TouchableOpacity
              key={i}
              activeOpacity={0.8}
              onPress={onECGPress}
            >
              <VitalCard {...v} />
            </TouchableOpacity>
          );
        }
        return <VitalCard key={i} {...v} />;
      })}
    </ScrollView>
  </View>
);

export default RightVitalsPanel;


// ─────────────────────────────────────────────
// STYLES
// ─────────────────────────────────────────────
const styles = StyleSheet.create({
  inner: {
    flex: 1,
    gap: 12,
    marginTop: 10,
  },

  // HEADER
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },

  headerTitle: {
    color: '#fff',
    fontSize: 13,
    fontWeight: '700',
  },

  headerSub: {
    color: '#9FB3C8',
    fontSize: 10,
    marginTop: 2,
  },

  closeBtn: {
    color: '#fff',
    fontSize: 16,
    padding: 4,
  },

  showTrendsBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    backgroundColor: '#21324B',
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 15,
    borderWidth: 1,
    borderColor: '#354458',
  },

  showTrendsText: {
    fontSize: 10,
    color: '#D2D6DB',
    fontWeight: '700',
  },

  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 8,
    overflow: 'hidden',
    paddingRight: 8,
    paddingVertical: 7,
    borderWidth: 1,
    borderColor: '#EEF0F4',
  },

  cardRed: { backgroundColor: '#FFF2F2', borderColor: '#FFCDD2' },
  cardOrange: { backgroundColor: '#FFF5E6', borderColor: '#FFE0B2' },

  accentBar: { width: 4, alignSelf: 'stretch', backgroundColor: '#34C759' },
  accentRed: { backgroundColor: '#E81314' },
  accentOrange: { backgroundColor: '#FC9432' },

  cardContent: { flex: 1, paddingLeft: 8 },

  cardLabel: { fontSize: 9, color: '#9DAFC4', marginBottom: 1 },

  cardValue: {
    fontSize: 12,
    fontWeight: '700',
    color: '#111',
  },

  cardUnit: {
    fontSize: 9,
    fontWeight: '400',
    color: '#8899AA',
  },

  textRed: { color: '#E81314' },
  textOrange: { color: '#FC9432' },
});